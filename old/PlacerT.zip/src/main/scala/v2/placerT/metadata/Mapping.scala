package main.scala.v2.placerT.metadata

import main.scala.v2.placerT.metadata.hw.{Bus, ProcessingElement}
import main.scala.v2.placerT.metadata.sw.{AtomicTask, Implementation, Transmission}


case class Mapping(taskMapping:Array[(AtomicTask,ProcessingElement,Implementation,Int,Int,Int)],
                   transmissionMapping:Array[(Transmission,ProcessingElement,ProcessingElement,Bus,Int,Int,Int)],
                    makeSpan:Int,
                    energy:Int){

  private def padToLength(s: String, l: Int) = (s + nStrings(l, " ")).substring(0, l)
  private def nStrings(n: Int, s: String): String = if (n <= 0) "" else s + nStrings(n - 1, s)


  override def toString: String = "Mapping(\n\t" +
    taskMapping.map(
    {case (task,pe,implem,start,dur,end) =>
      padToLength(task.name,22) + "implem:" +  padToLength(implem.name,22) + " on:" + padToLength(pe.name,15) + " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4)}).mkString("\n\t") + "\n\t" +
    transmissionMapping.map(
    {case (trans,fromPE,toPE,bus,start,dur,end) =>
      padToLength(trans.name,21)+ " from:" + padToLength(fromPE.name,10)+ " to:" +padToLength(toPE.name,10) +" on:" +padToLength(bus.name,15)+ " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4)}).mkString("\n\t") + "\n)"

  def toStringSorted: String = {
    val stringAndStart = taskMapping.map(
    {case (task,pe,implem,start,dur,end) =>
      (padToLength(task.name,22) + "implem:" +  padToLength(implem.name,22) + " on:" + padToLength(pe.name,15) +  " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4),start)}).toList ++
    transmissionMapping.map(
    {case (trans,fromPE,toPE,bus,start,dur,end) =>
      (padToLength(trans.name,21)+ " from:" + padToLength(fromPE.name,10)+ " to:" +padToLength(toPE.name,10) +" on:" +padToLength(bus.name,15)+ " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4),start)})
    "Mapping (makeSpan:" + makeSpan + " energy:" +energy+ "){\n\t" + stringAndStart.sortBy(_._2).map(_._1).mkString("\n\t") + "\n}"
  }

//+  "\n\tenergyConsumption:" + energyConsumption + ")"
}

abstract sealed class MappingGoal()
case class MinEnergy() extends MappingGoal()
case class MinMakeSpan() extends MappingGoal()
case class ParetoMakeSpanEnergy() extends MappingGoal()
