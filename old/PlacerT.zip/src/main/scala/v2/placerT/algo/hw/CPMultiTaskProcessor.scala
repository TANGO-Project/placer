package main.scala.v2.placerT.algo.hw

import main.scala.v2.placerT.algo.Mapper
import main.scala.v2.placerT.algo.sw.CPTask
import main.scala.v2.placerT.metadata.hw.{MultiTaskPermanentTasks, ProcessingElement}
import oscar.cp._
import oscar.cp.core.variables.CPIntVar

import scala.collection.immutable.SortedMap

/**
 * these processors are represented as bin-packing resoruces, pemanently allocated to the task, even if the only execute for a fraction of the time
 * @param id
 * @param p
 * @param memSize
 */
class CPMultiTaskProcessor(id: Int, p: ProcessingElement, memSize: Int, mapper:Mapper) extends CPProcessor(id, p, memSize,mapper) {
  require(p.processorClass.isInstanceOf[MultiTaskPermanentTasks])
  
  var tasksPotentiallyExecutingHere: List[CPTask] = List.empty

  val resourceToUsage: SortedMap[String, CPIntVar] = p.resources.mapValues(maxValue => CPIntVar(0, maxValue))

  override def accumulateExecutionConstraintsOnTask(task: CPTask) {
    accumulateTransmissionStorageOnTask(task)
    val isTaskExecutedHere = task.isRunningOnProcessor(id)
    if (!isTaskExecutedHere.isFalse) {
      tasksPotentiallyExecutingHere = task :: tasksPotentiallyExecutingHere
    }
  }

  override def close() {
    val x: List[(Array[CPBoolVar], SortedMap[String, Array[Int]])] =
      tasksPotentiallyExecutingHere.flatMap(t => t.buildArrayImplemAndMetricUsage(this))

    val isImplemSelectedSubArray = x.flatMap(_._1).toArray.asInstanceOf[Array[CPIntVar]]

    for ((resource, maxSize) <- p.resources) {
      val metricsForThisDimensionSubArray = x.flatMap(_._2.get(resource).get).toArray
      solver.add(weightedSum(metricsForThisDimensionSubArray,isImplemSelectedSubArray, resourceToUsage(resource)))
    }

    closeTransmissionAndComputationMemory()
  }

}