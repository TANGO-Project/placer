package main.scala.v2.placerT.algo.sw

import main.scala.v2.placerT.algo.Mapper
import oscar.cp.core.variables.CPIntVar

abstract class CPAbstractTask(mapper:Mapper){
  def start:CPIntVar
  def end:CPIntVar
  def duration:CPIntVar

  def variablesToDistribute:Iterable[CPIntVar]
}
