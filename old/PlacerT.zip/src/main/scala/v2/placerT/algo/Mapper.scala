package main.scala.v2.placerT.algo

import main.scala.v2.placerT.algo.hw._
import main.scala.v2.placerT.algo.sw.{CPTask, CPTransmission}
import main.scala.v2.placerT.metadata._
import main.scala.v2.placerT.metadata.hw._
import main.scala.v2.placerT.metadata.sw._
import oscar.cp._
import oscar.cp.modeling.Constraints

object Mapper{
  def findMapping(softwareModel:SoftwareModel, hardwareModel: HardwareModel,goal:MappingGoal):Iterable[Mapping] = {
    new Mapper(softwareModel, hardwareModel,goal:MappingGoal).mapping
  }
}

class Mapper(val softwareModel:SoftwareModel, val hardwareModel:HardwareModel, goal:MappingGoal) extends CPModel with Constraints {

  val cpProblem = postProblem(softwareModel, hardwareModel)
  val mapping = searchMappingProblem(cpProblem,goal)

  def postProblem(softwareModel: SoftwareModel,
                  hardwareModel: HardwareModel): CPMappingProblem = {

    val summedMaxTaskDurations =
      softwareModel.simpleProcesses.map(_.maxDuration(hardwareModel.processors)).sum
    val summedMaxTransmissionTimes =
      softwareModel.transmissions.map(flow => hardwareModel.busses.map(bus => bus.transmissionDuration(flow.size)).max).sum
    val maxHorizon = summedMaxTaskDurations + summedMaxTransmissionTimes

    val cpTasks: Array[CPTask] = softwareModel.simpleProcesses.map(
      process => new CPTask(process.id, process, process.name, this, maxHorizon)
    )

    val cpProcessors = hardwareModel.processors.map(
      processor => processor.processorClass match {
        case m: MultiTaskPermanentTasks => new CPMultiTaskProcessor(processor.id, processor, processor.memSize, this)
        case m: MonoTaskSwitchingTask => new CPMonoTaskProcessor(processor.id, processor, processor.memSize, m.switchingDelay, this)
      })

    val processorToBusAdjacencyNoSelfLoop: Set[(Int, Int)] =
      hardwareModel.busses.flatMap(bus => bus.receivingFromProcessors.map(proc => (proc.id, bus.id))).toSet

    val busToProcessorAdjacencyNoSelfLoop: Set[(Int, Int)] =
      hardwareModel.busses.flatMap(bus => bus.sendingToProcessors.map(proc => (bus.id, proc.id))).toSet

    val processorToBusToProcessorAdjacencyNoSelfLoop: Set[(Int, Int, Int)] = hardwareModel.busses.flatMap(
      bus => bus.receivingFromProcessors.flatMap(
        receivingFrom => bus.sendingToProcessors.flatMap(
          sendingTo =>
            if (receivingFrom != sendingTo) Some((receivingFrom.id, bus.id, sendingTo.id))
            else None))).toSet

    val selfLoopBusses = hardwareModel.processors.toList.map(
      proc => new CPSelfLoopBus(proc.id + hardwareModel.busses.length, proc, this))

    val processorToBusToProcessorAdjacency: Set[(Int, Int, Int)] =
      processorToBusToProcessorAdjacencyNoSelfLoop ++ selfLoopBusses.map((bus: CPSelfLoopBus) => (bus.id, bus.processor.id, bus.id))

    val cpBusses: Array[CPBus] = (hardwareModel.busses.toList.map(
      bus => new CPRegularBus(bus.id, bus, this)
    ) ++ selfLoopBusses).toArray

    val cpTransmissions: Array[CPTransmission] = softwareModel.transmissions.map(
      flow => new CPTransmission(flow.id, flow,
        cpTasks(flow.source.id), cpTasks(flow.target.id),
        cpBusses,
        flow.size, flow.name, flow.timing,
        this, maxHorizon,processorToBusToProcessorAdjacency)
    )

    //registering tasks and transmissions to processors and busses
    for (bus <- cpBusses) {
      for (transmission <- cpTransmissions) {
        bus.accumulatePotentialTransmissionOnBus(transmission)
      }
      bus.close()
    }

    for (proc <- cpProcessors) {
      for (task <- cpTasks) {
        proc.accumulateExecutionConstraintsOnTask(task)
      }
      proc.close()
    }

    val energyForEachTask = cpTasks.map(task => task.energy)
    val taskEnds = cpTasks.map(task => task.end)
    val backgroundPower: Int = cpProcessors.map(p => p.p.constantPower.value).sum
    val makeSpan = maximum(taskEnds)
    val energy = sum(energyForEachTask) + makeSpan * backgroundPower

    softwareModel.softwareClass match {
      case OneShotSoftware(Some(deadline)) => add(makeSpan <= deadline)
      case OneShotSoftware(None) => ;
    }

    CPMappingProblem(cpTasks,
      cpProcessors,
      cpBusses,
      cpTransmissions,
      makeSpan,
      energy)
  }

  def searchMappingProblem(problem: CPMappingProblem,goal: MappingGoal): Iterable[Mapping] = {

    goal match {
      case MinEnergy() => minimize(problem.energy)
      case MinMakeSpan() => minimize(problem.makeSpan)
      case ParetoMakeSpanEnergy() => solver.paretoMinimize(problem.makeSpan,problem.energy)
    }

    solver.addDecisionVariables(problem.varsToSave)

    search {
      binaryFirstFail(problem.varsToDistribute)
      //discrepancy(binaryFirstFail(problem.varsToDistribute), 5)
    } onSolution {
      println("solution found, makeSpan=" + problem.makeSpan.value + " energy:" + problem.energy.value)
    }

    val stat = start()

    println(stat)

    goal match {
      case ParetoMakeSpanEnergy() =>
        println(solver.nonDominatedSolutions)
        solver.nonDominatedSolutions.sortBy(_.apply(problem.makeSpan)).map(cpSol => problem.getMapping(cpSol))
      case MinEnergy() | MinMakeSpan()=>
        val lastSol = solver.lastSol
        if (lastSol.dict.isEmpty) {
          None
        } else {
          Some(problem.getMapping(lastSol))
        }
    }
  }
}
