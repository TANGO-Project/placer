package main.scala.v2.placerT.algo.hw

import main.scala.v2.placerT.algo.sw.CPTask
import main.scala.v2.placerT.algo.{Mapper, SimpleTask}
import main.scala.v2.placerT.metadata.hw.{MonoTaskSwitchingTask, ProcessingElement}

/**
 * these are represented as unary resources. furthermore, only tasks that can fit on this processor are allowed, statically
 * @param id
 * @param p
 * @param memSize
 */
class CPMonoTaskProcessor(id: Int, p: ProcessingElement, memSize: Int, switchingDelay:Int, mapper:Mapper)
  extends CPProcessor(id, p, memSize, mapper) {
  require(p.processorClass.isInstanceOf[MonoTaskSwitchingTask])

  var allSimpleTasksPotentiallyExecutingHere: List[SimpleTask] = List.empty
  var allTasksPotentiallyExecutingHere:List[CPTask] = List.empty

  override def accumulateExecutionConstraintsOnTask(task: CPTask) {
    accumulateTransmissionStorageOnTask(task)
    val isTaskExecutedHere = task.isRunningOnProcessor(id)

    if (!isTaskExecutedHere.isFalse) {
      //could be true, or unbound yet

      allTasksPotentiallyExecutingHere = task :: allTasksPotentiallyExecutingHere

      allSimpleTasksPotentiallyExecutingHere = SimpleTask(
        task.start,
        task.duration,
        task.end,
        isTaskExecutedHere) :: allSimpleTasksPotentiallyExecutingHere
    }
  }

  override def close(){
    SimpleTask.postUnaryResourceFromSimpleTasks(allSimpleTasksPotentiallyExecutingHere,switchingDelay)
    closeTransmissionAndComputationMemory()
  }
}
