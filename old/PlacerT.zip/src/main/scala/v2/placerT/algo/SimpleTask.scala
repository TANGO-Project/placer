package main.scala.v2.placerT.algo

import oscar.cp._
import oscar.cp.core.variables.CPIntVar
import oscar.cp.modeling.Constraints

case class SimpleTask(val start: CPIntVar, val duration: CPIntVar, val end: CPIntVar, val isNeeded: CPBoolVar)

object SimpleTask extends Constraints {

  def postUnaryResourceFromSimpleTasks(simpleTasks: List[SimpleTask], switchingDelay: Int = 0) {
    val simpleTasksArray = simpleTasks.filter(!_.isNeeded.isFalse).toArray
    val startTimeArray = simpleTasksArray.map(_.start)
    val endArray = simpleTasksArray.map(_.end)
    val durationArray = simpleTasksArray.map(_.duration)
    val isNeededArray = simpleTasksArray.map(_.isNeeded)

    val cp = startTimeArray(0).store
    val naive = false
    if (naive) {
      //ça ne va pas être très efficace du tout.
      if (switchingDelay != 0) {
        for {
          i <- startTimeArray.indices
          j <- i + 1 until startTimeArray.length
        } {
          cp.add((!isNeededArray(i)) || (!isNeededArray(j)) || (endArray(j) + switchingDelay <== startTimeArray(i)) || (endArray(i) + switchingDelay <== startTimeArray(j)))
        }
      }
    } else {
      for (t <- endArray.indices) {
        endArray(t) = endArray(t) + switchingDelay
        durationArray(t) = durationArray(t) + switchingDelay
      }
    }
    cp.add(unaryResource(startTimeArray, durationArray, endArray, isNeededArray))
  }
}


object CumulativeTask extends Constraints {
  def postCumulativeForSimpleCumulativeTasks(cumulativeTasks: List[CumulativeTask], maxResource: Int) {
    val simpleTasksArray = cumulativeTasks.filter(!_.amount.isBoundTo(0)).toArray
    val startTimeArray = simpleTasksArray.map(_.start)
    val endArray = simpleTasksArray.map(_.end)
    val durationArray = simpleTasksArray.map(_.duration)
    val amountArray = simpleTasksArray.map(_.amount)
    val cp = startTimeArray(0).store

    cp.add(maxCumulativeResource(startTimeArray, durationArray, endArray, amountArray, CPIntVar(maxResource)(cp)))
  }
}

case class CumulativeTask(start: CPIntVar, duration: CPIntVar, end: CPIntVar, amount: CPIntVar, explanation: String)




