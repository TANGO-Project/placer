package main.scala.v2.placerT.algo.sw

import main.scala.v2.placerT.algo.Mapper
import main.scala.v2.placerT.algo.hw.CPProcessor
import main.scala.v2.placerT.metadata.Formula
import main.scala.v2.placerT.metadata.sw.{AtomicTask, Implementation}
import oscar.cp
import oscar.cp._
import oscar.cp.core.variables.CPIntVar

import scala.collection.immutable.SortedMap

case class CPTask(id: Int,
                  task: AtomicTask,
                  explanation: String,
                  mapper:Mapper,
                  maxHorizon:Int)
  extends CPAbstractTask(mapper){
  implicit val solver = mapper.solver

  val start: CPIntVar = CPIntVar(0, maxHorizon)
  val end: CPIntVar = CPIntVar(0, maxHorizon)

  val processorID: CPIntVar = CPIntVar.sparse(mapper.hardwareModel.processors.indices)
  val implementationID: CPIntVar = CPIntVar.sparse(task.implementationArray.indices)

  val isRunningOnProcessor: Array[CPBoolVar] = mapper.hardwareModel.processors.map(processor => processorID isEq processor.id)
  val isImplementationSelected: Array[CPBoolVar] = task.implementationArray.map(implementation => implementationID isEq implementation.id)

  for (processor <- mapper.hardwareModel.processors) {
    if (!task.canRunOn(processor)) {
      isRunningOnProcessor.apply(processor.id).variable.assignFalse()
    }
  }

  val implemAndProcessorAndDurationAndEnergy:Iterable[(Int,Int,Int,Int)] =
    task.implementations.flatMap(
      implem => mapper.hardwareModel.processors.toList.
        filter(p => p.processorClass equals implem.target).
        map(p => {
          val durationPI = implem.duration(p)
          (implem.id,p.id,durationPI,durationPI * Formula.eval(p.powerModelForTask,p.processorClass.zeroResources ++ implem.resourceUsage))}))

  val possibleDurations = implemAndProcessorAndDurationAndEnergy.map(_._3)
  val duration: CPIntVar = CPIntVar.sparse(possibleDurations)

  val possibleEnergies = implemAndProcessorAndDurationAndEnergy.map(_._4)
  val energy: CPIntVar = CPIntVar.sparse(possibleEnergies)

  add(table(implementationID, processorID, duration, energy, implemAndProcessorAndDurationAndEnergy))
  add(end == (start + duration))

  def addIncomingTransmission(cPTransmission: CPTransmission): Unit = {
    incomingCPTransmissions = cPTransmission :: incomingCPTransmissions
  }

  def addOutgoingTransmission(cPTransmission: CPTransmission) {
    outgoingCPTransmissions = cPTransmission :: outgoingCPTransmissions
  }

  var incomingCPTransmissions: List[CPTransmission] = List.empty
  var outgoingCPTransmissions: List[CPTransmission] = List.empty

  val computationMemoryAndImplementation = task.implementations.map(i => (i.computationMemory,i.id))
  val computationMemories = computationMemoryAndImplementation.map(_._1)
  val computationMemory = CPIntVar.sparse(computationMemories)
  add(table(computationMemory,implementationID,computationMemoryAndImplementation))

  /**
   * given a target, we want an array, and a map from metric to array. all arays range on implementations
   * the first array contains CPBooVar telling if the implementation is selected
   * The map maps metrics to arrays that contains Int telling the size of the metric the implementation at this indice, from the first array)
   *
   * @param target
   */
  def buildArrayImplemAndMetricUsage(target: CPProcessor): Option[(Array[CPBoolVar], SortedMap[String, Array[Int]])] = {
    val processor = target.p
    val processorClass = processor.processorClass
    task.computingHardwareToImplementations.get(processorClass) match {
      case None => None
      case Some(Nil) => None
      case Some(implementations: List[Implementation]) =>
        val implementationSubArray = implementations.toArray
        val isThisImpementationSelectedSubArray = implementationSubArray.map(implementation => isImplementationSelected(implementation.id))

        val dimAndSizePerImplemSubArray:List[(String,Array[Int])] = processorClass.resources.toList.map((dimension:String) =>
          (dimension,implementationSubArray.map(implementation => implementation.resourceUsage(dimension))))

        val dimToSizesPerImplemSubArrays: SortedMap[String, Array[Int]] = SortedMap.empty[String, Array[Int]] ++ dimAndSizePerImplemSubArray

        Some((isThisImpementationSelectedSubArray, dimToSizesPerImplemSubArrays))
    }
  }

  override def variablesToDistribute: Iterable[cp.CPIntVar] = List(start,end,duration,implementationID,processorID)
}
