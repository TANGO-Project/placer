package main.scala.v1.metadata.hw

//general problem about monitorability: what if some other task must wait for another one to finish
//and they are not on the same processor, and not linked by any transmission?

import main.scala.v1.metadata._

import scala.collection.immutable.{SortedMap, SortedSet}

abstract sealed class SwitchingModel{
  def checkPowerModel(powerModel:Formula)
}

/**
 * like a FPGA: can perform many tasks at the same time, but cannot be re-fitted with other tasks (approximation)
 * we do not have switching in this case because switching can be performed only when all tasks are competed,
 * and it is very difficult to represent this in the optimization model
 */
case class MultiTaskPermanentTasks() extends SwitchingModel{
  def checkPowerModel(powerModel:Formula){
    //must be linear
    require(Formula.isLinear(powerModel),"power model must be linear wrt dimensions for multi-task switching model")
  }
}
//bin-packing non-timed (since permanent use), but task still have duration

/**
 * can only perform a single task at a time, and there is a delay to switch to another task.
 * during this delay, it does nothing
 * @param switchingDelay
 */
case class MonoTaskSwitchingTask(switchingDelay:Int) extends SwitchingModel{
  def checkPowerModel(powerModel:Formula){
    //nothing particular here.
  }
}
// unaryResource(starts: Array[CPIntVar], durations: Array[CPIntVar], ends: Array[CPIntVar], required: Array[CPBoolVar])

/**
 * @param name
 * @param definedDimensions
 * @param switching: the kind of switching that the hardware is able to do
 */
case class ProcessingElementClass(name:String,
                                  definedDimensions:SortedSet[String],
                                  switching:SwitchingModel)
  extends Indiced with Ordered[ProcessingElementClass]{

  override def compare(that: ProcessingElementClass): Int = this.name compare that.name

  override def toString: String = "ProcessingElementClass(" + name + " dimensions:{" + definedDimensions.mkString(",") + "}" + " switching:" + switching + ")"

  def checkPowerModel(powerModel:Formula){
    switching.checkPowerModel(powerModel:Formula)
  }

  val zeroMetrics:SortedMap[String,Int] = SortedMap.empty[String,Int] ++ definedDimensions.map(d => (d,0))
}

/**
 *
 * @param processorClass
 * @param dimensions
 * @param name
 * @param memSize
 * @param powerModel is the power that the processor consumes. dimensions are set to zero when nothing executes. must be linear for multiTask processors
 */
case class ProcessingElement(processorClass:ProcessingElementClass,
                             dimensions:SortedMap[String,Int],
                             name:String,
                             memSize:Int,
                             powerModel:Formula)
  extends Indiced() with Ordered[ProcessingElement]{

  processorClass.checkPowerModel(powerModel)
  require(dimensions.keySet subsetOf processorClass.definedDimensions,
    "unknown dimension specified in " + name + ": " + (dimensions.keySet -- processorClass.definedDimensions).mkString(","))
  require(processorClass.definedDimensions subsetOf dimensions.keySet ,
    "missing dimension in " + name + ": " + (processorClass.definedDimensions-- dimensions.keySet).mkString(","))
  require(powerModel.terms subsetOf processorClass.definedDimensions,
    "unknown terms specified in powermodel of " + name + ": " +
      (powerModel.terms -- processorClass.definedDimensions).mkString(","))

  val (constantPower:Const,powerModelForTask:Formula) = Formula.splitConstant(powerModel)


  override def toString: String = "ProcessingElement(" + name + " " +
    processorClass.name + "(" + dimensions.toList.map({case (a,b) => a + ":" + b}).mkString(" ") + ") localMem:" + memSize +
    " powerModel:" + powerModel.prettyPrint() + ")"

  override def compare(that: ProcessingElement): Int = {
    require(this.id != -1)
    require(that.id != -1)
    this.id compare that.id
  }
}


//communication share  busses.
//we can choose: either round-robin scheme for the whole bus, or prioritized
//prioritized = transmissions are not split
//round-robin bus = transmissions cut into chunks, and chuncks transmitted into round-robin scheme (chunnk size = param of the bus)



//do we share communications or not??
//i propose to split all communication into chunks that are actual tasks, and prioritize on chunks
//bus are therefore unaryResource
sealed abstract class Bus(val name:String, val timeUnitPerBit:Int, val delay:Int) extends Indiced(){
  require(timeUnitPerBit >= 0, "creating bus " + name + " with unauthorized timeUnitPerBit:" + timeUnitPerBit)
  require(delay >= 0, "creating bus " + name + " with unauthorized delay:" + delay)


  def close()
  def canReceiveFlowFrom(p:ProcessingElement):Boolean
  def canSentFlowTo(p:ProcessingElement):Boolean
  def receivingFromProcessors:Set[ProcessingElement]
  def sendingToProcessors:Set[ProcessingElement]

  /**
   * compute the duration for transmissing a certain amount of data.
   * delay + size * timeUnitPerBit
   * @param size
   * @return
   */
  def transmissionDuration(size:Int):Int = delay + size * timeUnitPerBit
}

case class HalfDuplexBus(relatedProcessors:List[ProcessingElement],
                                     override val timeUnitPerBit:Int,
                                     override val delay:Int,
                                     override val name:String)
  extends Bus(name,timeUnitPerBit,delay) {

  override def toString: String = "HalfDuplexBus(" +
    name + " processors:{" + relatedProcessors.map(_.name).mkString(",") + "} timeUnitPerBit:" +
    timeUnitPerBit + " delay:" + delay + ")"

  var relatedProcessorSet:SortedSet[ProcessingElement] = null

  def close(): Unit ={
    relatedProcessorSet = SortedSet.empty[ProcessingElement] ++ relatedProcessors
  }

  override def canReceiveFlowFrom(p: ProcessingElement): Boolean = relatedProcessorSet.contains(p)

  override def canSentFlowTo(p: ProcessingElement): Boolean = relatedProcessorSet.contains(p)

  override def receivingFromProcessors: Set[ProcessingElement] = relatedProcessorSet

  override def sendingToProcessors: Set[ProcessingElement] = relatedProcessorSet
}

case class SingleWayBus(private val from:List[ProcessingElement],
                        to:List[ProcessingElement],
                        override val timeUnitPerBit:Int,
                        override val delay:Int,
                        override val name:String)
  extends Bus(name,timeUnitPerBit,delay) {

  override def toString: String = "SingleWayBus(" + name +
    " from:{" + from.map(_.name).mkString(",") + "} to:{" +
    to.map(_.name).mkString(",") + "} timeUnitPerBit:" +
    timeUnitPerBit + " delay:" + delay + ")"

  var fromProcessorSet:SortedSet[ProcessingElement] = null
  var toProcessorSet:SortedSet[ProcessingElement] = null

  def close(): Unit ={
    fromProcessorSet = SortedSet.empty[ProcessingElement] ++ from
    toProcessorSet = SortedSet.empty[ProcessingElement] ++ to
  }

  override def canReceiveFlowFrom(p: ProcessingElement): Boolean = fromProcessorSet.contains(p)

  override def canSentFlowTo(p: ProcessingElement): Boolean = toProcessorSet.contains(p)

  override def receivingFromProcessors: Set[ProcessingElement] = fromProcessorSet

  override def sendingToProcessors: Set[ProcessingElement] = toProcessorSet
}


case class SelfLoopBus(proc:ProcessingElement) extends Bus("local loop on " + proc.name,0, 0){

  override def toString: String = "local loop on " + proc.name

  override def close(){}

  override def sendingToProcessors: Set[ProcessingElement] = Set(proc)

  override def canSentFlowTo(p: ProcessingElement): Boolean = p == proc

  override def receivingFromProcessors: Set[ProcessingElement] = Set(proc)

  override def canReceiveFlowFrom(p: ProcessingElement): Boolean = p == proc
}


case class HardwareModel(processors:Array[ProcessingElement],
                         busses:Array[Bus],
                         processorClasses:Array[ProcessingElementClass]) extends IndiceMaker{
  setIndices(processors)
  setIndices(busses)
  setIndices(processorClasses)
  busses.foreach(_.close())

  override def toString: String = "HardwareModel(\n" +
    "\tclasses:{\n\t\t" + processorClasses.mkString(",\n\t\t") + "}\n" +
    "\tprocessors:{\n\t\t" + processors.mkString(",\n\t\t") + "} \n" +
    "\tbusses:{\n\t\t" + busses.mkString(",\n\t\t") + "}\n" +
    ")"
}

