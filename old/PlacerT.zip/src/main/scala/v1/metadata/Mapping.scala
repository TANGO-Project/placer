package main.scala.v1.metadata

import main.scala.v1.metadata.hw.{Bus, ProcessingElement}
import main.scala.v1.metadata.sw.{AtomicTask, Implementation, Transmission}


case class Mapping(taskMapping:Array[(AtomicTask,ProcessingElement,Implementation,Int,Int,Int)],
                   transmissionMapping:Array[(Transmission,ProcessingElement,ProcessingElement,Bus,Int,Int,Int)]){

  private def padToLength(s: String, l: Int) = (s + nStrings(l, " ")).substring(0, l)
  private def nStrings(n: Int, s: String): String = if (n <= 0) "" else s + nStrings(n - 1, s)


  override def toString: String = "Mapping(\n\t" +
    taskMapping.map(
    {case (task,pe,implem,start,dur,end) =>
      padToLength(task.name,51) + " on:" + padToLength(pe.name,15) + " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4)}).mkString("\n\t") + "\n\t" +
    transmissionMapping.map(
    {case (trans,fromPE,toPE,bus,start,dur,end) =>
      padToLength(trans.name,21)+ " from:" + padToLength(fromPE.name,10)+ " to:" +padToLength(toPE.name,10) +" on:" +padToLength(bus.name,15)+ " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4)}).mkString("\n\t") + "\n)"

  def toStringSorted: String = {
    val stringAndStart = taskMapping.map(
    {case (task,pe,implem,start,dur,end) =>
      (padToLength(task.name,51) + " on:" + padToLength(pe.name,15) + " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4),start)}).toList ++
    transmissionMapping.map(
    {case (trans,fromPE,toPE,bus,start,dur,end) =>
      (padToLength(trans.name,21)+ " from:" + padToLength(fromPE.name,10)+ " to:" +padToLength(toPE.name,10) +" on:" +padToLength(bus.name,15)+ " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4),start)})
    "Mapping(sorted)(\n\t" + stringAndStart.sortBy(_._2).map(_._1).mkString("\n\t") + "\n)"
  }

//+  "\n\tenergyConsumption:" + energyConsumption + ")"
}

abstract sealed class MappingGoal()
case class MinEnergy() extends MappingGoal()
case class MakeSpan() extends MappingGoal()
