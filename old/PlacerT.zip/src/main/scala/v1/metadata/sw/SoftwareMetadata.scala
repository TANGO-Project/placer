package main.scala.v1.metadata.sw

import main.scala.v1.metadata._
import main.scala.v1.metadata.hw._

import scala.collection.immutable.SortedMap

/**
 *
 * @param target
 * @param metrics
 * @param computationMemory is the memory needed toperform the computation. We consider that the memory tat stores input and output data is allocated for the duration of the task.
 * @param durationEstimator
 */
case class Implementation(target:ProcessingElementClass,
                          metrics:SortedMap[String,Int],
                          computationMemory:Int,
                          durationEstimator:Formula) extends Indiced{

  require(metrics.keySet subsetOf target.definedDimensions, "unknown dimension specified in implementation " + target + ": " + (metrics.keySet -- target.definedDimensions).mkString(","))
  require(durationEstimator.terms subsetOf target.definedDimensions, "duration is defined based on unknown terms in implementation " + target + ": " + (metrics.keySet -- durationEstimator.terms).mkString(","))

  override def toString: String = {
    "Implementation(target:" + target.name + " metrics{" + metrics.toList.map({ case (a, b) => a + ":" + b }).mkString(",") + "} durationEstimator:" + durationEstimator.prettyPrint() + ")"
  }

  def duration(proc:ProcessingElement):Int = {
    require(proc.processorClass == target,"cannot evaluate WCET on processor class " + proc + " for implementation for " + target)
    Formula.eval(durationEstimator,proc.dimensions)
  }
}

case class AtomicTask(implementations:List[Implementation],
                      name:String)extends Indiced() with IndiceMaker{

  val implementationArray = implementations.toArray
  setIndices(implementationArray)
  val computingHardwareToImplementations:Map[ProcessingElementClass,List[Implementation]] = implementations.groupBy(_.target)

  override def toString: String = "Process(" + name + " implems:{" + implementations.mkString(";") + "})"

  def canRunOn(p:ProcessingElement):Boolean = {
    computingHardwareToImplementations.get(p.processorClass) match {
      case None => return false
      case Some(Nil) => return false
      case Some(implementationList) =>
        for(implementation <- implementationList){
          val metrics = implementation.metrics
          if (metrics.forall({case (dim, req) => (p.dimensions.get(dim).head >= req)})) {
            return true
          }
        }
    }
    true
  }

  def maxDuration(procs:Iterable[ProcessingElement]):Int = {
    var maxDur = 0
    for(proc <- procs){
      for(implem<-computingHardwareToImplementations.getOrElse(proc.processorClass,List.empty)){
        val dur = implem.duration(proc)
        if(dur > maxDur) maxDur = dur
      }
    }
    maxDur
  }
}

object TransmissionTiming extends Enumeration {
  type TransmissionTiming = Value
  val Asap, Alap, Free = Value
}
import TransmissionTiming._

//on peut avoir des flux vers les process atomiques, auquel cas, c'est additioné par process sur le même HW; on peutaussi avoir des communication vers le Groupe,
// auquel cas, chaque process a besoin de la totalité du flux; c'st donc partagé si deux process du groupe sont sur le même HW

//transmission uses the amount of memory on source until terminated, and uses amount of memory on destination until consuming task started
case class Transmission(source:AtomicTask,
                        target:AtomicTask,
                        size:Int,
                        timing:TransmissionTiming,
                        name:String) extends Indiced(){
  override def toString: String = "Transmission("+ name + " " + source.name + "->" + target.name + " size:" + size + ")"

  def shortString:String = "Transmission(" + name + " " + source.name + "->" + target.name + ")"
}

/**
 *
 * @param simpleProcesses the processes
 * @param transmissions the transmissions between processes
 * @param softwareClass the class of software, and its time requirements
 */
case class SoftwareModel(simpleProcesses:Array[AtomicTask], 
                         transmissions:Array[Transmission],
                         softwareClass:SoftwareClass) extends IndiceMaker{
  setIndices(simpleProcesses)
  setIndices(transmissions)

  require(transmissions.forall(f => f.source.id != -1 && f.target.id != -1),"some transmissions refer to non-registered tasks")

  override def toString: String = "SoftwareModel(\n" +
    "\tsimpleProcesses:[\n\t\t" + simpleProcesses.mkString(",\n\t\t") + "] \n" +
    "\ttransmissions:[\n\t\t" + transmissions.mkString(",\n\t\t") + "])"
}

abstract sealed class SoftwareClass()
case class OneShotSoftware(endToEndDelay:Option[Int]) extends SoftwareClass()
case class StreamingSofttware(endToEndDelay:Option[Int],frameDelay:Option[Int]) extends SoftwareClass()

