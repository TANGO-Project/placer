package main.scala.v1

import main.scala.v1.algo.Mapper
import main.scala.v1.metadata.hw._
import main.scala.v1.metadata.sw.TransmissionTiming._
import main.scala.v1.metadata.sw._
import main.scala.v1.metadata.{Dim, MinEnergy}

import scala.collection.immutable.{SortedMap, SortedSet}

object Example1 extends App {

  //hardware metamodel
  val cpu = ProcessingElementClass("cpu",SortedSet("flops","ops"),MonoTaskSwitchingTask(1))
  val fpga = ProcessingElementClass("fpga",SortedSet("kgate","multiplier"),MultiTaskPermanentTasks())
  val gpgpu = ProcessingElementClass("gpgpu",SortedSet("core"),MonoTaskSwitchingTask(1))

  //hardware model
  val processorA = ProcessingElement(
    cpu,
    SortedMap("flops" -> 10,"ops" -> 1000),
    "procA",
    100,
    powerModel = Dim("flops")*30 + 5)
  val processorB = ProcessingElement(
    gpgpu,
    SortedMap("core" -> 110),
    "GPGPU",
    200,
    powerModel = Dim("core")*5 + 10)
  val processorC = ProcessingElement(cpu,
    SortedMap("flops" -> 6,"ops" -> 100),
    "procC",
    100,
    powerModel = Dim("flops")*20 + 1)
  val processorD = ProcessingElement(
    fpga,
    SortedMap("kgate" -> 100000, "multiplier" -> 500),
    "FPGA",
    100,
    powerModel = Dim("kgate") + Dim("multiplier")*200 + 2)

  val globalBus = HalfDuplexBus(
    List(processorA, processorB, processorC,processorD),
    3,
    1,
    "globalBus")
  val globalBus2 = HalfDuplexBus(
    List(processorA, processorB, processorC,processorD),
    4,
    1,
    "globalBus2")
  val busAB = HalfDuplexBus(
    List(processorA, processorB),
    1,
    1,
    "busAtoGPGPU")
  val busBC = HalfDuplexBus(
    List(processorB, processorC),
    2,
    1,
    "busCToCoGPGPU")
  val busAD = HalfDuplexBus(
    List(processorA,processorD),
    1,
    3,
    "busAToFPGA")

  val hardwareModel = HardwareModel(
    Array(processorA, processorB, processorC,processorD),
    Array(globalBus, busAB, busBC,busAD,globalBus2),
    Array(cpu,gpgpu,fpga))

  println(hardwareModel)

  // software model
  val inputting = AtomicTask(
    List(
      Implementation(cpu, SortedMap.empty,                              10,   100/Dim("flops")+1000/Dim("ops")),
      Implementation(fpga,SortedMap("kgate" -> 100, "multiplier" -> 30),100,  5)),
    "inputting")
  val decoding = AtomicTask(
    List(
      Implementation(cpu, SortedMap.empty,100,10/Dim("flops")+100000/Dim("ops")),
      Implementation(cpu, SortedMap.empty,10,100/Dim("flops")+1000/Dim("ops")),
      Implementation(fpga, SortedMap("kgate" -> 100, "multiplier" -> 20),10,10),
      Implementation(gpgpu,SortedMap("core"->100),10,10)),
    "decoding")
  val transforming = AtomicTask(List(
    Implementation(cpu,SortedMap.empty,10,110/Dim("flops")+1000/Dim("ops")),
    Implementation(gpgpu,SortedMap("core"->1),10,10)),
    "Transforming")
  val transforming2 = AtomicTask(List(
    Implementation(cpu,SortedMap.empty,10,110/Dim("flops")+1000/Dim("ops")),
    Implementation(gpgpu,SortedMap("core"->1),10,10)),
    "Transforming2")
  val watermarking = AtomicTask(List(
    Implementation(cpu,SortedMap.empty,0,100/Dim("flops")+1000/Dim("ops")),
    Implementation(fpga,SortedMap("kgate" -> 20,"multiplier" -> 30),10,1),
    Implementation(gpgpu,SortedMap("core"->100),10,10)),
    "watermarking")
  val encoding = AtomicTask(
    List(Implementation(cpu,SortedMap.empty,10,100/Dim("flops")+1000/Dim("ops"))),
    "encoding")

  val inputToDecode = Transmission(inputting, decoding, 50, timing = Free,"inputToDecode")
  val decodeToTransform = Transmission(decoding, transforming, 2, timing = Asap,"decodeToTransform")
  val transformToWatermark = Transmission(transforming, watermarking, 2, timing = Asap,"transformToWatermark")
  val decodeToTransform2 = Transmission(decoding, transforming2, 2, timing = Asap,"decodeToTransform2")
  val transform2ToWatermark = Transmission(transforming2, watermarking, 2, timing = Asap,"transform2ToWatermark")
  val watermarkToEncode = Transmission(watermarking, encoding, 20, timing = Asap,"watermarkToEncode")
  val sideComm = Transmission(inputting, encoding, 5, timing = Free,"side_comm")

  val softwareModel = SoftwareModel(
    Array(inputting, decoding, transforming,transforming2,watermarking, encoding),
    Array(inputToDecode, decodeToTransform, transformToWatermark, decodeToTransform2, transform2ToWatermark,watermarkToEncode, sideComm),
    OneShotSoftware(None))

  println(softwareModel)

  val goal = MinEnergy() //MakeSpan()

  val mappingSol = Mapper.findMapping(softwareModel,hardwareModel,goal)

  mappingSol match {
    case None => println("No mapping found")
    case Some(mapping) =>
      println(mapping)
      println(mapping.toStringSorted)
  }
}
