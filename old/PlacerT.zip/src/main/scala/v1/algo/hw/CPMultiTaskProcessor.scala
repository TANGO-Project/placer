package main.scala.v1.algo.hw

import main.scala.v1.algo
import main.scala.v1.algo.sw.CPTask
import main.scala.v1.metadata.hw.{MultiTaskPermanentTasks, ProcessingElement}
import oscar.cp._
import oscar.cp.core.variables.CPIntVar

import scala.collection.immutable.SortedMap

/**
 * these processors are represented as bin-packing resoruces, pemanently allocated to the task, even if the only execute for a fraction of the time
 * @param id
 * @param p
 * @param memSize
 */
class CPMultiTaskProcessor(id: Int, p: ProcessingElement, memSize: Int, mapper:algo.Mapper) extends CPProcessor(id, p, memSize,mapper) {
  require(p.processorClass.switching.isInstanceOf[MultiTaskPermanentTasks])
  
  var tasksPotentiallyExecutingHere: List[CPTask] = List.empty

  val dimensionToUsage: SortedMap[String, CPIntVar] = p.dimensions.mapValues(maxValue => CPIntVar(0, maxValue))

  override def accumulateExecutionConstraintsOnTask(task: CPTask) {
    accumulateTransmissionStorageOnTask(task)
    val isTaskExecutedHere = task.isRunningOnProcessor(id)
    if (!isTaskExecutedHere.isFalse) {
      tasksPotentiallyExecutingHere = task :: tasksPotentiallyExecutingHere
    }
  }

  override def close() {
    val x: List[(Array[CPBoolVar], SortedMap[String, Array[Int]])] =
      tasksPotentiallyExecutingHere.flatMap(t => t.buildArrayImplemAndMetricUsage(this))

    val isImplemSelectedSubArray = x.flatMap(_._1).toArray.asInstanceOf[Array[CPIntVar]]

    for ((dimension, maxSize) <- p.dimensions) {
      val metricsForThisDimensionSubArray = x.flatMap(_._2.get(dimension).get).toArray
      solver.add(weightedSum(metricsForThisDimensionSubArray,isImplemSelectedSubArray, dimensionToUsage(dimension)))
    }

    closeTransmissionAndComputationMemory()
  }

}