package main.scala.v1.algo.hw

import main.scala.v1.algo
import main.scala.v1.algo.sw.CPTask
import main.scala.v1.metadata.hw.{MonoTaskSwitchingTask, ProcessingElement}

/**
 * these are represented as unary resources. furthermore, only tasks that can fit on this processor are allowed, statically
 * @param id
 * @param p
 * @param memSize
 */
class CPMonoTaskProcessor(id: Int, p: ProcessingElement, memSize: Int, switchingDelay:Int, mapper:algo.Mapper)
  extends CPProcessor(id, p, memSize, mapper) {
  require(p.processorClass.switching.isInstanceOf[MonoTaskSwitchingTask])

  var allSimpleTasksPotentiallyExecutingHere: List[algo.SimpleTask] = List.empty
  var allTasksPotentiallyExecutingHere:List[CPTask] = List.empty

  override def accumulateExecutionConstraintsOnTask(task: CPTask) {
    accumulateTransmissionStorageOnTask(task)
    val isTaskExecutedHere = task.isRunningOnProcessor(id)

    if (!isTaskExecutedHere.isFalse) {
      //could be true, or unbound yet

      allTasksPotentiallyExecutingHere = task :: allTasksPotentiallyExecutingHere

      allSimpleTasksPotentiallyExecutingHere = algo.SimpleTask(
        task.start,
        task.duration,
        task.end,
        isTaskExecutedHere) :: allSimpleTasksPotentiallyExecutingHere
    }
  }

  override def close(){
    algo.SimpleTask.postUnaryResourceFromSimpleTasks(allSimpleTasksPotentiallyExecutingHere,switchingDelay)
    closeTransmissionAndComputationMemory()
  }
}
