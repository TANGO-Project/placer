package main.scala.v1.algo.hw

import main.scala.v1.algo.sw.CPTransmission
import main.scala.v1.algo.{Mapper, SimpleTask}
import main.scala.v1.metadata.hw.{Bus, ProcessingElement, SelfLoopBus}


/**
 * a bus is a unary resource
 * @param id
 * @param bus
 */
abstract class CPBus(val id:Int, mapper:Mapper){

  def accumulatePotentialTransmissionOnBus(transmission:CPTransmission)

  def transmissionDuration(size:Int):Int

  def close()
}

case class CPRegularBus(override val id:Int, bus:Bus, mapper:Mapper) extends CPBus(id:Int, mapper:Mapper){

  private var allSimpleTasksPotentiallyExecutingHere: List[SimpleTask] = List.empty

  override def accumulatePotentialTransmissionOnBus(transmission:CPTransmission){
    val isTransmissionOccurringHere = transmission.isOccurringOnBus(id)

    if (!isTransmissionOccurringHere.isFalse) {
      //could be true, or unbound yet
      allSimpleTasksPotentiallyExecutingHere = SimpleTask(
        transmission.start,
        transmission.duration,
        transmission.end,
        isTransmissionOccurringHere) :: allSimpleTasksPotentiallyExecutingHere
    }
  }

  override def transmissionDuration(size:Int):Int = bus.delay + size * bus.timeUnitPerBit

  override  def close() {
    if (allSimpleTasksPotentiallyExecutingHere.isEmpty) {
      println("WARNING: no transmission will fit on bus " + bus.name)
    } else {
      SimpleTask.postUnaryResourceFromSimpleTasks(allSimpleTasksPotentiallyExecutingHere)
    }
  }
}

case class CPSelfLoopBus(override val id:Int, processor:ProcessingElement, mapper:Mapper) extends CPBus(id:Int, mapper:Mapper){

  override def transmissionDuration(size:Int):Int = 0

  override def accumulatePotentialTransmissionOnBus(transmission:CPTransmission){}

  override def close(){}

  def selfLoopBus = SelfLoopBus(processor)
}