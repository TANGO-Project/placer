package main.scala.v1.algo

import main.scala.v1.algo.hw._
import main.scala.v1.algo.sw.{CPTransmission, CPTask}
import main.scala.v1.metadata._
import main.scala.v1.metadata.hw._
import main.scala.v1.metadata.sw._
import oscar.cp._
import oscar.cp.modeling.Constraints

object Mapper{
  def findMapping(softwareModel:SoftwareModel, hardwareModel: HardwareModel,goal:MappingGoal):Option[Mapping] = {
    new Mapper(softwareModel, hardwareModel,goal:MappingGoal).mapping
  }
}

class Mapper(val softwareModel:SoftwareModel, val hardwareModel:HardwareModel, goal:MappingGoal) extends CPModel with Constraints{

  val summedMaxTaskdurations =
    softwareModel.simpleProcesses.map(_.maxDuration(hardwareModel.processors)).sum
  val summedMaxTransmissionTimes =
    softwareModel.transmissions.map(flow => hardwareModel.busses.map(bus => bus.transmissionDuration(flow.size)).max).sum
  val maxHorizon = summedMaxTaskdurations + summedMaxTransmissionTimes

  val cpTasks: Array[CPTask] = softwareModel.simpleProcesses.map(
    process => new CPTask(process.id, process, process.name,this)
  )

  val cpProcessors = hardwareModel.processors.map(
    processor => processor.processorClass.switching match{
      case MultiTaskPermanentTasks() => new hw.CPMultiTaskProcessor(processor.id,processor,processor.memSize,this)
      case MonoTaskSwitchingTask(switchingDelay) => new hw.CPMonoTaskProcessor(processor.id,processor,processor.memSize,switchingDelay,this)
    })

  private val processorToBusAdjacencyNoSelfLoop: Set[(Int, Int)] =
    hardwareModel.busses.flatMap(bus => bus.receivingFromProcessors.map(proc => (proc.id, bus.id))).toSet

  private val busToProcessorAdjacencyNoSelfLoop: Set[(Int, Int)] =
    hardwareModel.busses.flatMap(bus => bus.sendingToProcessors.map(proc => (bus.id, proc.id))).toSet

  val processorToBusToProcessorAdjacencyNoSelfLoop:Set[(Int,Int,Int)] = hardwareModel.busses.flatMap(
    bus => bus.receivingFromProcessors.flatMap(
      receivingFrom => bus.sendingToProcessors.flatMap(
        sendingTo =>
          if(receivingFrom != sendingTo) Some((receivingFrom.id,bus.id,sendingTo.id))
          else None))).toSet

  val selfLoopBusses = hardwareModel.processors.toList.map(
    proc => new CPSelfLoopBus(proc.id + hardwareModel.busses.size, proc, this))

  val processorToBusToProcessorAdjacency:Set[(Int,Int,Int)] =
    processorToBusToProcessorAdjacencyNoSelfLoop ++ selfLoopBusses.map((bus:CPSelfLoopBus) => (bus.id,bus.processor.id,bus.id))

  val cpBusses: Array[CPBus] = (hardwareModel.busses.toList.map(
    bus => new CPRegularBus(bus.id, bus, this)
  ) ++ selfLoopBusses).toArray

  val cpTransmissions: Array[CPTransmission] = softwareModel.transmissions.map(
    flow => new CPTransmission(flow.id, flow, cpTasks(flow.source.id), cpTasks(flow.target.id), cpBusses, flow.size, flow.name,flow.timing,this)
  )

  //registering tasks and transmissions to processors and busses
  for(bus <- cpBusses){
    for(transmission <- cpTransmissions){
      bus.accumulatePotentialTransmissionOnBus(transmission)
    }
    bus.close()
  }

  for(proc <- cpProcessors){
    for(task <- cpTasks){
      proc.accumulateExecutionConstraintsOnTask(task)
    }
    proc.close()
  }

  val energyForEachTask = cpTasks.map(task => task.energy)
  val taskEnds = cpTasks.map(task => task.end)
  val backgroundPower:Int = cpProcessors.map(p => p.p.constantPower.value).sum
  val makeSpan = maximum(taskEnds)

  val objectiveFunction = goal match{
    case MinEnergy() =>
      sum(energyForEachTask) + makeSpan * backgroundPower
    case MakeSpan() => makeSpan
  }

  minimize(objectiveFunction)

  val allVariablesToDistribute = List.empty[CPIntVar] ++ cpTasks.flatMap(_.variablesToDistribute) ++ cpTransmissions.flatMap(_.variablesToDistribute)

  solver.addDecisionVariables(allVariablesToDistribute)

  val mapping:Option[Mapping] = {
    search{
      discrepancy(binaryFirstFail(allVariablesToDistribute),5)
    }  onSolution{
      println("solution found, makeSpan=" + makeSpan.value)

    }

    //solver.lastSol
    val stat = start()
    //solve

    println(stat)
    //get info back through indices

    val lastSol = solver.lastSol

    if(lastSol.dict.isEmpty){
      None
    }else{

      def proc(procID:CPIntVar):ProcessingElement = cpProcessors(lastSol(procID)).p
      def implem(task:CPTask):Implementation = task.task.implementationArray(lastSol(task.implementationID))

      val taskMapping = cpTasks.map(cpTask => (cpTask.task, proc(cpTask.processorID), implem(cpTask),
        lastSol(cpTask.start),lastSol(cpTask.duration),lastSol(cpTask.end)))

      def bus(cPTransmission: CPTransmission):Bus = cPTransmission.busses(lastSol(cPTransmission.busID)) match{
        case c:CPSelfLoopBus => c.selfLoopBus
        case b:CPRegularBus => b.bus
      }

      val transmissionMapping = cpTransmissions.map(trans =>
        (trans.transmission, proc(trans.from.processorID),proc(trans.to.processorID),bus(trans),lastSol(trans.start),lastSol(trans.duration),lastSol(trans.end)))

      Some(new Mapping(taskMapping, transmissionMapping))

    }
  }
}
