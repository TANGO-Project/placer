package main.scala.placerT.algo.sw

import main.scala.placerT.algo.Mapper
import oscar.cp.core.variables.CPIntVar

abstract class CPAbstractTask(mapper:Mapper){
  def start:CPIntVar
  def end:CPIntVar
  def duration:CPIntVar

  def variablesToDistribute:Iterable[CPIntVar]
}
