package main.scala.placerT.algo

import main.scala.placerT.algo.hw.{CPRegularBus, CPSelfLoopBus, CPBus, CPProcessor}
import main.scala.placerT.algo.sw.{CPTransmission, CPTask}
import main.scala.placerT.metadata.Mapping
import main.scala.placerT.metadata.hw.{Bus, ProcessingElement}
import main.scala.placerT.metadata.sw.FlattenedImplementation

import oscar.cp._
import oscar.cp.core.CPSol

/**
 * Created by rdl on 10-04-17.
 */
case class CPMappingProblem(cpTasks: Array[CPTask],
                       cpProcessors:Array[CPProcessor],
                       cpBusses: Array[CPBus],
                       cpTransmissions: Array[CPTransmission],
                       makeSpan:CPIntVar,
                       energy:CPIntVar) {

  def getMapping(sol:CPSol):Mapping = {

    def proc(procID: CPIntVar): ProcessingElement = cpProcessors(sol(procID)).p
    def implem(task: CPTask): FlattenedImplementation = task.task.implementationArray(sol(task.implementationID))

    val taskMapping = cpTasks.map(cpTask => (cpTask.task, proc(cpTask.processorID), implem(cpTask),
      sol(cpTask.start), sol(cpTask.duration), sol(cpTask.end)))

    def bus(cPTransmission: CPTransmission): Bus = cPTransmission.busses(sol(cPTransmission.busID)) match {
      case c: CPSelfLoopBus => c.selfLoopBus
      case b: CPRegularBus => b.bus
    }

    val transmissionMapping = cpTransmissions.map(trans =>
      (trans.transmission, proc(trans.from.processorID), proc(trans.to.processorID), bus(trans), sol(trans.start), sol(trans.duration), sol(trans.end)))

    new Mapping(taskMapping, transmissionMapping,sol(makeSpan),sol(energy))
  }

  def varsToDistribute:List[CPIntVar] = {
    List.empty ++
      cpTasks.flatMap(_.variablesToDistribute) ++
      cpTransmissions.flatMap(_.variablesToDistribute)
  }

  def varsToSave:List[CPIntVar] = makeSpan :: energy :: varsToDistribute

}
