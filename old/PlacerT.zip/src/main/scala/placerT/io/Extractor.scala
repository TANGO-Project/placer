package placerT.io

import main.scala.placerT.metadata.sw._
import main.scala.placerT.metadata.Formula
import main.scala.placerT.metadata.MappingGoal.MappingGoal
import main.scala.placerT.metadata.hw._
import net.liftweb.json.DefaultFormats
import net.liftweb.json.JsonAST.JValue
import placerT.metadata.MappingProblem
import main.scala.placerT.metadata.sw.TransmissionTiming._

import scala.collection.immutable.{SortedMap, SortedSet}
import main.scala.placerT.metadata.MappingGoal._

/**
 * Created by rdl on 17-05-17.
 */
object Extractor {
  implicit val formats = DefaultFormats // Brings in default date formats etc.
  def extractProblem(jValue: JValue):MappingProblem = {
    jValue.extract[EMappingProblem].extract
  }
}

case class EMappingProblem(softwareModel:ESoftwareModel,
                           hardwareModel:EHardwareModel,
                           goal:String){

  def extract = {
    val hw = hardwareModel.extract
    val sw = softwareModel.extract(hw)
    MappingProblem(sw,hw,goal match{
      case "MinEnergy" => MinEnergy
      case "MinMakeSpan" =>MinMakeSpan
      case "ParetoMakeSpanEnergy" => ParetoMakeSpanEnergy
    })
  }
}

case class ESoftwareModel(simpleProcesses:Array[EAtomicTask],
                          transmissions:Array[ETransmission],
                          softwareClass:ESoftwareClass){
  def extract(hw:HardwareModel) = {
    val proc = simpleProcesses.map(_.extract(hw))
    SoftwareModel(
      proc,
      transmissions.map(_.extract(proc)),
      softwareClass.extract)
  }
}
case class ESoftwareClass(oneShotSoftware:Option[EOneShotSoftware]){
  def extract = oneShotSoftware match{
    case Some(s) => s.extract
    case None => throw new Error("software class not defined")
  }
}
case class EOneShotSoftware(maxDelay:Option[Int]){
  def extract = OneShotSoftware(maxDelay)
}

case class EAtomicTask(name:String,
                       implementations:List[EParametricImplementation]){
  def extract(hw:HardwareModel) = {
    AtomicTask(implementations.map(_.extract(hw)),
      name)
  }
}

case class ENameValue(name:String,value:Int){
  def toCouple:(String,Int) = (name,value)
}

case class EParametricImplementation(name:String,
                                     target:String,
                                     resourceUsage:List[ENameFormula],
                                     computationMemory:String,
                                     duration:String,
                                     parameters:List[ENameValues]){
  val parsedComputationMemory = FormulaParser(computationMemory)
  val parsedDuration = FormulaParser(duration)

  def extract(hw:HardwareModel) =
    ParametricImplementation(name,
      hw.processorClasses.find(_.name equals target).get,
      SortedMap.empty[String,Formula] ++ resourceUsage.map(_.extract),
      parsedComputationMemory,
      parsedDuration,
      SortedMap.empty[String,Iterable[Int]] ++ parameters.map(_.extract))
}
case class ENameValues(name:String,values:List[Int]){
  def extract = (name,values)
}
case class ENameFormula(name:String,formula:String){
  val parsedFormula = FormulaParser(formula)
  def extract:(String,Formula) = (name,parsedFormula)
}
case class ETransmission(source:String,
                         target:String,
                         size:Int,
                         timing:String,
                         name:String){
  def extract(a:Array[AtomicTask]) =
    Transmission(
      a.find(t => t.name equals source).get,
      a.find(t => t.name equals target).get,
      size,
      timing match{
        case "Asap" => Asap
        case "Alap" => Alap
        case "Free" => Free
      },
      name)
}

case class EProcessingElementClass(multiTaskPermanentTasks:Option[EMultiTaskPermanentTasks],monoTaskSwitchingTask: Option[EMonoTaskSwitchingTask]){
  def extract:ProcessingElementClass = {
    (multiTaskPermanentTasks,monoTaskSwitchingTask) match{
      case (None,None) => throw new Error("Processing element not specified")
      case (Some(a),None) => a.extract
      case (None,Some(a)) => a.extract
      case (Some(_),Some(_)) => throw new Error("Processing element specified twice")
    }
  }
}

case class EMultiTaskPermanentTasks(name:String,resources:List[String],properties:List[String]){
  def extract:MultiTaskPermanentTasks = MultiTaskPermanentTasks(name,SortedSet.empty[String] ++ resources,SortedSet.empty[String] ++ properties)
}
case class EMonoTaskSwitchingTask(name:String,resources:List[String],properties:List[String],switchingDelay:Int){
  def extract:MonoTaskSwitchingTask = MonoTaskSwitchingTask(name,SortedSet.empty[String] ++ resources,SortedSet.empty[String] ++ properties,switchingDelay)
}

case class EProcessingElement(processorClass:String,
                              resources:List[ENameValue],
                              properties:List[ENameValue],
                              name:String,
                              memSize:Int,
                              powerModel:String){
  val parsedPowerModel = FormulaParser(powerModel)
  def extract(pc:Array[ProcessingElementClass]):ProcessingElement = ProcessingElement(
    pc.find(_.name equals processorClass).get,
    SortedMap.empty[String,Int] ++ resources.map(_.toCouple),
    SortedMap.empty[String,Int] ++ properties.map(_.toCouple),
    name,
    memSize,
    parsedPowerModel
  )
}

case class EBus(halfDuplexBus: Option[EHalfDuplexBus],singleWayBus: Option[ESingleWayBus]){
  def extract(p:Array[ProcessingElement]):Bus = {
    (halfDuplexBus,singleWayBus) match{
      case (None,None) => throw new Error("Bus element not specified")
      case (Some(a),None) => a.extract(p)
      case (None,Some(a)) => a.extract(p)
      case (Some(_),Some(_)) => throw new Error("Bus element specified twice")
    }
  }
}

case class EHalfDuplexBus(relatedProcessors:List[String],
                          timeUnitPerBit:Int,
                          latency:Int,
                          name:String){
  def extract(p:Array[ProcessingElement]) = HalfDuplexBus(
    relatedProcessors.map(name => p.find(_.name equals name).get),
    timeUnitPerBit,
    latency,
    name)
}

case class ESingleWayBus(from:List[String],
                         to:List[String],
                         timeUnitPerBit:Int,
                         latency:Int,
                         name:String){
  def extract(p:Array[ProcessingElement]) = SingleWayBus(
    from.map(name => p.find(_.name equals name).get),
    to.map(name => p.find(_.name equals name).get),
    timeUnitPerBit,
    latency,
    name)
}

case class EHardwareModel(processors:Array[EProcessingElement],
                          busses:Array[EBus],
                          classes:Array[EProcessingElementClass],
                          powerCap:Option[Int],
                          energyCap:Option[Int]){
  def extract = {
    val pc = classes.map(_.extract)
    val p = processors.map(_.extract(pc))
    val b = busses.map(_.extract(p))
    HardwareModel(p,b,pc,powerCap,energyCap)
  }
}