package main.scala.placerT.io

import main.scala.placerT.metadata.hw.{ProcessingElementClass, HardwareModel}
import net.liftweb.json._


object Reader extends App{

  val parsed = parse(""" { "numbers" : [1, 2, 3, 4] } """)

  println(parsed)

  println(compactRender(parsed))

  println(JSonHelper.int("a",5))
  println(JSonHelper.string("attribute","stringValue"))
  println(JSonHelper.strings("attribute",List("strValue1","strValue2")))

}

object JSonHelper{
  def strings(attribute:String,strings:Iterable[String]):String = {
    """"""" + attribute + """":[""" + strings.map(""""""" + _ + """"""").mkString(",") + "]"
  }

  def multiples(attribute:String,strings:Iterable[String]):String = {
    """"""" + attribute + """":[""" + strings.mkString(",") + "]"
  }

  def int(attribute:String,value:Int):String = {
    """"""" + attribute + """":""" + value
  }

  def string(attribute:String,value:String):String = {
    """"""" + attribute + """":"""" + value + """""""
  }

  def complex(attribute:String,value:String):String = {
    """"""" + attribute + """":""" + value
  }

}
