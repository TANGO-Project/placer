package placerT.io

import main.scala.placerT.metadata._
import net.liftweb.json.MappingException

import scala.util.parsing.combinator.RegexParsers

/**
 * Created by rdl on 17-05-17.
 */
object FormulaParser{
  def apply(s:String):Formula = new FormulaParser().apply(s)
}

class FormulaParser() extends RegexParsers {
  def apply(s:String):Formula = {
    val tmp = parseAll(formula, s)
    tmp match{
      case Success(result,_) => result
      case n:NoSuccess  => {
        println(n)
        throw new MappingException(n.toString)
      }
    }
  }

  def formula:Parser[Formula] = expr

  def expr: Parser[Formula] =
    term ~ rep("[+-]".r ~ term) ^^ {
    case t ~ ts => ts.foldLeft(t) {
      case (t1, "+" ~ t2) => Plus(t1, t2)
      case (t1, "-" ~ t2) => Minus(t1, t2)
    }
  }

  def term: Parser[Formula] =
    factor ~ rep("[*/]".r ~ factor) ^^ {
    case t ~ ts => ts.foldLeft(t) {
      case (t1, "*" ~ t2) => Times(t1, t2)
      case (t1, "/" ~ t2) => Div(t1, t2)
    }
  }

  def factor: Parser[Formula] = ("(" ~> expr <~ ")") | naturalParser | identifier

  def naturalParser:Parser[Formula] = """[0-9]+""".r ^^ {case s:String => Const(s.toInt)}

  def identifier:Parser[Formula] =  """[a-zA-Z_]+""".r ^^ {case s => Dim(s.toString)}
}
