package main.scala.placerT.metadata


trait IndiceMaker{
  def setIndices[T<:Indiced](x:Array[T]): Unit ={
    for(i <- x.indices){
      require(x(i).id == -1,"indiced element " + x(i) + " already indiced")
      x(i).id = i
    }
  }
}

class Indiced(var id:Int = -1)
