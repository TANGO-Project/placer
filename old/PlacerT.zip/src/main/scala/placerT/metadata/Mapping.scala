package main.scala.placerT.metadata

import main.scala.placerT.io.JSonHelper
import main.scala.placerT.metadata.hw.{ProcessingElement, Bus}
import main.scala.placerT.metadata.sw.{FlattenedImplementation, AtomicTask, Transmission}


case class Mapping(taskMapping:Array[(AtomicTask,ProcessingElement,FlattenedImplementation,Int,Int,Int)],
                   transmissionMapping:Array[(Transmission,ProcessingElement,ProcessingElement,Bus,Int,Int,Int)],
                   makeSpan:Int,
                   energy:Int){

  private def padToLength(s: String, l: Int) = (s + nStrings(l, " ")).substring(0, l)
  private def nStrings(n: Int, s: String): String = if (n <= 0) "" else s + nStrings(n - 1, s)


  override def toString: String = "Mapping(\n\t" +
    taskMapping.map(
    {case (task,pe,implem,start,dur,end) =>
      padToLength(task.name,22) + "implem:" +  padToLength(implem.description,22) + " on:" + padToLength(pe.name,15) + " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4)}).mkString("\n\t") + "\n\t" +
    transmissionMapping.map(
    {case (trans,fromPE,toPE,bus,start,dur,end) =>
      padToLength(trans.name,21)+ " from:" + padToLength(fromPE.name,10)+ " to:" +padToLength(toPE.name,10) +" on:" +padToLength(bus.name,15)+ " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4)}).mkString("\n\t") + "\n)"

  def toStringSorted: String = {
    val stringAndStart = taskMapping.map(
    {case (task,pe,implem,start,dur,end) =>
      (padToLength(task.name,22) + "implem:" +  padToLength(implem.description,22) + " on:" + padToLength(pe.name,15) +  " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4),start)}).toList ++
      transmissionMapping.map(
      {case (trans,fromPE,toPE,bus,start,dur,end) =>
        (padToLength(trans.name,21)+ " from:" + padToLength(fromPE.name,10)+ " to:" +padToLength(toPE.name,10) +" on:" +padToLength(bus.name,15)+ " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4),start)})
    "Mapping (makeSpan:" + makeSpan + " energy:" +energy+ "){\n\t" + stringAndStart.sortBy(_._2).map(_._1).mkString("\n\t") + "\n}"
  }

  def toStringSortedLight: String = {
    val stringAndStart = taskMapping.map(
    {case (task,pe,implem,start,dur,end) =>
      (padToLength(task.name,22) + " " + padToLength(pe.name + "(" + implem.description + ")",25) +  " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4),start)}).toList ++
      transmissionMapping.map(
      {case (trans,fromPE,toPE,bus,start,dur,end) =>
        (padToLength(trans.name,22) +" " +padToLength(bus.name,25)+ " start:" + padToLength(""+start ,4)+ " dur:" + padToLength(""+dur,4) + "end:" + padToLength(""+end,4),start)})
    "Mapping (makeSpan:" + makeSpan + " energy:" +energy+ "){\n\t" + stringAndStart.sortBy(_._2).map(_._1).mkString("\n\t") + "\n}"
  }


  def toJSon:String = "{" +
    JSonHelper.int("makeSpan",makeSpan) + "," +
    JSonHelper.int("energy",energy) + "," +
    JSonHelper.multiples("taskMapping",taskMapping.map(taskMappingToJSon(_))) + "," +
    JSonHelper.multiples("transmissionMapping",transmissionMapping.map(transmissionMappingToJSon(_))) + "}"

  def taskMappingToJSon(m:(AtomicTask,ProcessingElement,FlattenedImplementation,Int,Int,Int)):String = {
    "{" + JSonHelper.string("task",m._1.name) + "," +
      JSonHelper.string("processingElement",m._2.name) + "," +
      JSonHelper.string("implementation",m._3.name) +
      JSonHelper.multiples("parameters",m._3.parameterValues.map({case (name,value) => "{" + JSonHelper.string("name",name) + "," + JSonHelper.int("value",value) + "}"})) + "," +
      sdetoJSon(m._4,m._5,m._6) + "}"
  }

  def transmissionMappingToJSon(m:(Transmission,ProcessingElement,ProcessingElement,Bus,Int,Int,Int)):String = {
    "{" +
      JSonHelper.string("transmission",m._1.name) + "," +
      JSonHelper.string("bus",m._4.name) + "," +
      sdetoJSon(m._5,m._6,m._7) + "}"
  }

  def sdetoJSon(s:Int,d:Int,e:Int):String = {
    JSonHelper.int("start",s) + "," +
      JSonHelper.int("duration",d) + "," +
      JSonHelper.int("end",e)
  }
}


case class Mappings(mapping:Iterable[Mapping]){
  def toJSon:String = {
    "{" + JSonHelper.multiples("mappings",mapping.map(_.toJSon)) + "}"
  }
}


object MappingGoal extends Enumeration {
  type MappingGoal = Value
  val MinEnergy, MinMakeSpan, ParetoMakeSpanEnergy = Value
}
import main.scala.placerT.metadata.MappingGoal._

