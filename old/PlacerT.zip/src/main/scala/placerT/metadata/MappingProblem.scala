package placerT.metadata

import main.scala.placerT.io.JSonHelper
import main.scala.placerT.metadata.MappingGoal
import main.scala.placerT.metadata.MappingGoal.MappingGoal
import main.scala.placerT.metadata.hw.HardwareModel
import main.scala.placerT.metadata.sw.SoftwareModel
import net.liftweb.json.JValue

/**
 * Created by rdl on 17-05-17.
 */
case class MappingProblem(softwareModel:SoftwareModel,hardwareModel:HardwareModel,goal:MappingGoal){

  def toJSon:String = "{" +
    JSonHelper.complex("softwareModel",softwareModel.toJSon) + "," +
    JSonHelper.complex("hardwareModel",hardwareModel.toJSon) + "," +
    JSonHelper.string("goal",goal.toString) + "}"
}
