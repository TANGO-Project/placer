package placerT

import main.scala.placerT.{ExampleTenerifeData, ExampleTenerife}
import main.scala.placerT.algo.Mapper
import net.liftweb.json._
import placerT.io.Extractor
import placerT.metadata.MappingProblem

import scala.io.Source
import java.io.{PrintWriter, File}


case class Config(in: File = new File("."), out: File = new File("."),  verbose: Boolean = false)

/**
 * Created by rdl on 17-05-17.
 */
object Main extends App {

  val parser = new scopt.OptionParser[Config]("placer") {
    head("placer", "0.1")

    opt[File]('i', "in").required().valueName("<file>").
      action( (x, c) => c.copy(in = x) ).
      text("'in' is the JSon file prepresenting the placement problem")

    opt[File]('o', "out").required().valueName("<file>").
      action( (x, c) => c.copy(out = x) ).
      text("'out' is the file where the JSon representing the placements will be stored")

    opt[Unit]("verbose").action( (_, c) =>
      c.copy(verbose = true) ).text("pretty prints the content of the JSon file")

    help("help").text("prints this usage text")

  }

  // parser.parse returns Option[C]
  parser.parse(args, Config()) match {
    case None =>
    // arguments are bad, error message will have been displayed
    case Some(config) =>
      // do stuff

      val problemFile = Source.fromFile(config.in)
      val parsed = parse(problemFile.mkString)
      val problem:MappingProblem = Extractor.extractProblem(parsed)

      if (config.verbose) println(problem)
      val mappingSet = Mapper.findMapping(problem)

      if (config.verbose) {
        if (mappingSet.mapping.isEmpty) {
          println("no mapping found")
        } else {
          println("" + mappingSet.mapping.size + " mapping found")
          for (mapping <- mappingSet.mapping) {
            println(mapping.makeSpan + " " + mapping.energy)
          }
          for (mapping <- mappingSet.mapping) {
            println(mapping.toStringSortedLight)
          }
        }
      }

      val outJSon = mappingSet.toJSon
      new PrintWriter(config.out) { write(prettyRender(parse(outJSon))); close }
  }
}

