package main.scala.placer.metadata

import main.scala.placer.metadata.hw._
import main.scala.placer.metadata.sw._

case class Mapping(simpleProcessOnProcesor:List[(AtomicProcess,Processor)],
                   groupsOnProcessor:List[(ProcessGroup,List[(Processor,Int)])],
                   flowOnBus:List[String],
                   energyConsumption:Int){
  override def toString: String = "Mapping(\n\t" +
    simpleProcessOnProcesor.map({case (process,processor) => process.name + " -> " + processor.name}).mkString("\n\t") + "\n\t" +
    groupsOnProcessor.map({case (process,spread) => process.name + " -> {" + spread.map({case (processor:Processor,i) => processor.name + ":" + i}).mkString(",") + "}"}).mkString("\n\t") + "\n\t" +
    flowOnBus.mkString("\n\t") + "\n\tenergyConsumption:" + energyConsumption + ")"

}

class IndiceMaker(){
  def setIndices[T<:Indiced](x:Array[T]): Unit ={
    for(i <- x.indices){
      require(x(i).id == -1,"indiced element " + x(i) + " already indiced")
      x(i).id = i
    }
  }
}

class Indiced(var id:Int = -1)
