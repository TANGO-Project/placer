package main.scala.placer.algo

import main.scala.placer.metadata._
import main.scala.placer.metadata.hw._
import main.scala.placer.metadata.sw._
import oscar.cp._
import oscar.cp.core.CPPropagStrength

import scala.collection.immutable.{SortedSet, SortedMap}

object Mapper{
  def findMapping(softwareModel:SoftwareModel, hardwareModel: HardwareModel):Option[Mapping] = {
    new Mapper(softwareModel, hardwareModel).findMapping
  }
}

class Mapper(softwareModel:SoftwareModel, hardwareModel: HardwareModel) extends CPModel {

  //creating some ranges and constants
  val simpleProcessRange = softwareModel.simpleProcesses.indices
  val flowsRange = softwareModel.flows.indices
  val processorRange = hardwareModel.processors.indices
  val bussesRange = hardwareModel.busses.indices

  val selfLoopBusConstant = hardwareModel.busses.length

  val subprocessesRange = softwareModel.subProcesses.indices
  val processGroupRange = softwareModel.groups.indices

  val classesToProcessors:Map[ComputingHardware,Iterable[Processor]] =
    (SortedMap.empty[ComputingHardware,Iterable[Processor]]
      ++ hardwareModel.processorClasses.map(x => (x,List.empty))
      ++ hardwareModel.processors.toList.groupBy(p => p.processorClass))

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //accumulators for of decision variables

  var decisionVarForBusses:List[CPIntVar] = List.empty
  def accumulateDecisionVariableForFlow(decisionVar:CPIntVar){
    decisionVarForBusses = decisionVar :: decisionVarForBusses
  }

  var decisionVarsForProcesses:List[CPIntVar] = List.empty
  def accumulateDecisionVariableForProcesses(decisionVar:CPIntVar){
    decisionVarsForProcesses = decisionVar :: decisionVarsForProcesses
  }


  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //model of processes

  val simpleProcessesIdToProcessorIDVarAndProcessorToIsThereVar:Array[(CPIntVar,Map[Processor,CPBoolVar])] = Array.tabulate(simpleProcessRange.size)(processID => {
    val process = softwareModel.simpleProcesses(processID)
    val allowedProcessorsOfSupportedClass = process.implementations.keys.flatMap(classesToProcessors)
    val allowedProcessorsOfSupportedClassAndBigEnough = allowedProcessorsOfSupportedClass.filter(process.canRunOn(_))
    val IndicesOfAllowedProcessorsOfSupportedClassAndBigEnough = allowedProcessorsOfSupportedClassAndBigEnough.map(_.id)

    val processorID = CPIntVar(IndicesOfAllowedProcessorsOfSupportedClassAndBigEnough,"processor_of_process" + process.name)
    accumulateDecisionVariableForProcesses(processorID)

    val processorToIsThere:Map[Processor,CPBoolVar] =
      allowedProcessorsOfSupportedClassAndBigEnough.toList.map(processor => (processor,processorID.isEq(processor.id))).toMap
    (processorID,processorToIsThere)
  })

  val simpleProcessesIdToProcessorIdVar = simpleProcessesIdToProcessorIDVarAndProcessorToIsThereVar.map(_._1)

  val subProcessesIDToSubProcessAndProcessorToNBInstancesOFSubProcessOnProcessor:Array[(AtomicProcess,Map[Processor,CPIntVar])] =
    Array.tabulate(subprocessesRange.size)(subProcessID => {
      val subProcess = softwareModel.subProcesses(subProcessID)
      val allowedProcessorsOfSupportedClass = subProcess.implementations.keys.flatMap(classesToProcessors)
      val allowedProcessorsOfSupportedClassAndBigEnough = allowedProcessorsOfSupportedClass.filter(subProcess.canRunOn(_))

      val procToNBInstance = allowedProcessorsOfSupportedClassAndBigEnough.toList.map(processor =>
        (processor, {
          val theVar = CPIntVar(0 to subProcess.group.head.n,
            "nbInstance_of_" + subProcess.name + "_on_processor_" + processor.name)
          accumulateDecisionVariableForProcesses(theVar)
          theVar
        }))

      (subProcess,procToNBInstance.toMap)
    })

  //contrainte: le nombre de process atomic est donné, pour chaque groupe
  for(group <- softwareModel.groups){
    val atomicProcess = group.processTemplate
    val varsOnAllSupportingHardware = subProcessesIDToSubProcessAndProcessorToNBInstancesOFSubProcessOnProcessor(atomicProcess.id)._2.values
    //checked
    add(sum(varsOnAllSupportingHardware.toArray) === group.n)
  }

  val groupProcessToProcessorToIsRunning:Array[(ProcessGroup,Map[Processor,CPBoolVar])] =
    Array.tabulate(processGroupRange.size)(groupProcessID => {
      val processGroup = softwareModel.groups(groupProcessID)
      val allowedProcessorsOfSupportedClassAndBigEnough = hardwareModel.processors.filter(processor => processGroup.canPartlyRunOn(processor))

      val procToAnySubProcess = allowedProcessorsOfSupportedClassAndBigEnough.toList.map(processor =>
        (processor,CPBoolVar("any_instance_of_" + processGroup.name + "_on_processor_" + processor.name)))

      (processGroup,procToAnySubProcess.toMap)
    })

  //contrainte de cohérence groupe et subProcess
  for((group,processorToIsRunning) <- groupProcessToProcessorToIsRunning) {
    val processorToNBInstanceofSubProcess = subProcessesIDToSubProcessAndProcessorToNBInstancesOFSubProcessOnProcessor(group.processTemplate.id)
    for((processor,isRunning) <- processorToIsRunning){
      val nbInstanceOfSubProcess = processorToNBInstanceofSubProcess._2(processor)
      //checked
      add((nbInstanceOfSubProcess isGrEq 1) ===  isRunning)
    }
  }

  //classes -> dimensions -> array, one position per instance

  //contrainte1: la somme des métriques des process partageant le même processeur est <= métrique du processeur, pour chaque processeur
  //Cette contrainte est ventilée par classe de processeurs
  val processorsToDimensionsToUsage:Map[Processor,Map[String,CPIntVar]] =
    SortedMap.empty[Processor,Map[String,CPIntVar]] ++
      hardwareModel.processors.toList.map((processor:Processor) => (processor,{
        val processorClass = processor.processorClass
        val simpleProcessesThatCanRunOnProcessor = softwareModel.simpleProcesses.filter(_.canRunOn(processor)).toList

        val potentialSubProcessesAndNBInstanceVar:Iterable[(AtomicProcess,CPIntVar)] =
          subProcessesIDToSubProcessAndProcessorToNBInstancesOFSubProcessOnProcessor.flatMap(
          {case (subProcess,implementationVariables) =>
            if(subProcess.canRunOn(processor)) Some(subProcess,implementationVariables(processor))
            else None
          })

        val potentialSubProcessesNBInstanceVar:Iterable[CPIntVar] = potentialSubProcessesAndNBInstanceVar.map(_._2)

        if(processorClass.multiTask){
          val dimToUsageList = processor.dimensions.toList.map({
            case (dimName,maxValueOnDimension) => (dimName,CPIntVar(0 to maxValueOnDimension,processor.name + "." + dimName))
          })

          val isSimpleProcessRunningOnThisProcessor:Iterable[CPIntVar] = simpleProcessesThatCanRunOnProcessor.map(process =>
            simpleProcessesIdToProcessorIDVarAndProcessorToIsThereVar(process.id)._2.getOrElse(processor,CPBoolVar(false)))

          for((dimension,usage) <- dimToUsageList) {
            //post knapsack stuff
            val simpleProcessSizeOnThisDimension = simpleProcessesThatCanRunOnProcessor.map(process => process.implementations(processorClass)(dimension))

            val potentialSubProcessSizeOnThisDimension:Iterable[Int] =
              potentialSubProcessesAndNBInstanceVar.map(_._1.implementations(processorClass)(dimension))

            add(weightedSum(
              (simpleProcessSizeOnThisDimension ::: potentialSubProcessSizeOnThisDimension.toList).toArray,
              (isSimpleProcessRunningOnThisProcessor.toList ::: potentialSubProcessesNBInstanceVar.toList).toArray,
              usage))
          }

          dimToUsageList.toMap
        } else {
          //only one dim: in use or not

          val isProcessorUsed = CPIntVar(0 to 1,processor.name + "." + "inUse")

          val processorOfPotentialProcesses = simpleProcessesThatCanRunOnProcessor.map(process =>
            simpleProcessesIdToProcessorIdVar(process.id)).toArray

          val allGroupIsRunnigOnThisProcessor = groupProcessToProcessorToIsRunning.flatMap({case (group,procToIsRunning) => procToIsRunning.get(processor)})

          //checked, potential error
          add(countEq(isProcessorUsed - sum(allGroupIsRunnigOnThisProcessor) , processorOfPotentialProcesses, processor.id),CPPropagStrength.Strong)

          //basically, since there is only one group running on such processor, we can pre-compute the max value for the number of sub processes allowed here

          for((subProcess,nbInstanceVar) <- potentialSubProcessesAndNBInstanceVar){
            //checked, potentrial error
            add(nbInstanceVar <= subProcess.maxInstancesOn(processor))
          }

          SortedMap("inUse" -> isProcessorUsed)
        }}))



  //contrainte redondante:
  //pour chaque classe de processeur multi, et chaque dim, la somme des usage sur cette dim et cette classe
  // est comprise entre la somme des dims des processus qui doivent aller sur cette classe et ceux qui peuvent aller sur cette classe
  for((processorClass,processorList) <- classesToProcessors if processorClass.multiTask){
    val exclusiveAndImplementation = softwareModel.simpleProcesses.flatMap(process => process.implementations.get(processorClass) match{
      case None => None
      case Some(dimentionToReq) => Some((process.implementations.size == 1,dimentionToReq))
    })

    val exclusivesImplementations = exclusiveAndImplementation.flatMap({case (isExclusive,implem) => if(isExclusive) Some(implem) else None})
    val nonExclusivesImplementations = exclusiveAndImplementation.flatMap({case (isExclusive,implem) => if(!isExclusive) Some(implem) else None})

    for(dimension <- processorClass.dimensions){
      val sizeOfExclusivesOnDim = exclusivesImplementations.map(_(dimension)).sum
      val sizeOfNonExclusiveOnDim = nonExclusivesImplementations.map(_(dimension)).sum

      val summedUsageOfAllProcesorInTheClassOnThisDimension =
        (if(processorList.isEmpty) CPIntVar(0) else sum(processorList.map(p => processorsToDimensionsToUsage(p)(dimension))))

      add(summedUsageOfAllProcesorInTheClassOnThisDimension >= sizeOfExclusivesOnDim)
      add(summedUsageOfAllProcesorInTheClassOnThisDimension <= (sizeOfExclusivesOnDim + sizeOfNonExclusiveOnDim))
    }
  }

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //model of flows


  //il y a 6 types de flow (sans compter les symétriques):
  //simple - simple de place1 à place2,taille constante
  //simple - group de place1 à toutes les places2, taille constante
  //simple - sub de place1 à toutes les places2 aggrégées, taille variable
  //group - group
  //group - sub
  //sub - sub


  //pour chaque bus hardware, on accumule les CPIntVAr et les facteurs de pondération, puis on fait une somme pondérée.
  //il n'y a plus de self loop

  val bussesAccumulator:Array[List[(CPIntVar,Int)]] = Array.fill(bussesRange.size)(List.empty)

  val processorToBusAdjacencyNoSelfLoop1:Set[(Int,Int)] = hardwareModel.busses.flatMap(bus => bus.receivingFromProcessors.map(proc => ((proc.id,bus.id)))).toSet
  val busToProcessorAdjacencyNoSelfLoop1:Set[(Int,Int)] = hardwareModel.busses.flatMap(bus => bus.sendingToProcessors.map(proc => ((bus.id,proc.id)))).toSet
  val processorToBusAdjacencyAbstractBusForSelfLoop1:Set[(Int,Int)] = processorToBusAdjacencyNoSelfLoop1 ++ processorRange.map(proc => (proc,selfLoopBusConstant))
  val busToProcessorAdjacencyAbstractBusForSelfLoop1:Set[(Int,Int)] = busToProcessorAdjacencyNoSelfLoop1 ++ processorRange.map(proc => (selfLoopBusConstant,proc))

  val processorToProcessorAdjacencyWithAddedSelfLoop1:Iterable[(Int,Int)] =
    (SortedSet.empty[(Int,Int)]
      ++ hardwareModel.busses.flatMap(bus =>
      bus.receivingFromProcessors.flatMap(sendingProc =>
        bus.sendingToProcessors.map(receivingProc => (sendingProc.id,receivingProc.id))))
      ++ hardwareModel.processors.indices.map(i => (i,i)))

  def accumulateTransmissionOnBus(busId:Int,variable:CPIntVar,weight:Int){
    bussesAccumulator(busId) = (variable,weight) :: bussesAccumulator(busId)
  }

  var flowMapExplanations:List[FlowMapExplanation] = List.empty

  def accumulateFlowMappingExplanation(e:FlowMapExplanation){
    flowMapExplanations = e :: flowMapExplanations
  }

  sealed abstract class FlowMapExplanation(flow:Flow){
    def explanation: Iterable[String]
  }
  class SimpleSimpleFlowExplanation(flow:Flow, busOfTransmission:CPIntVar) extends FlowMapExplanation(flow){
    override def explanation: Iterable[String] = {
      if(busOfTransmission.value == selfLoopBusConstant) Some(flow.shortString + " ->  local loop")
      else Some(flow.shortString + " -> " + hardwareModel.busses(busOfTransmission.value).name)
    }
  }

  class SimpleToSubProcessFlowExplanation(flow:Flow,
                                          processorOfSimpleProcess:CPIntVar,
                                          subProcess:Process,
                                          busToProcessorToFlowInstances:Map[Int,Map[Processor,CPIntVar]],
                                          procToNBInstanceOfSubProcess:Map[Processor,CPIntVar],
                                          flippedBusses:Boolean)
    extends FlowMapExplanation(flow) {

    def simpleXSubProcess: String = if(flippedBusses) " from " else " to "

    override def explanation: Iterable[String] = {
      procToNBInstanceOfSubProcess.toList.flatMap({ case (proc, nbInstancesOfSubProcess) => {
        if (nbInstancesOfSubProcess.value == 0) None
        else {
          val header = flow.shortString + simpleXSubProcess + proc.name + "(" + nbInstancesOfSubProcess.value + " flows)"

          if (processorOfSimpleProcess.value == proc.id) Some(header + " -> local loop")
          else {
            val busToFlowInstance: List[String] = busToProcessorToFlowInstances.toList.flatMap({ case (busID, procToFlowInstance) => procToFlowInstance.get(proc) match {
              case Some(v) if v.value > 0 => Some(hardwareModel.busses(busID).name + ":" + v.value)
              case _ => None
            }
            })
            Some(header + " -> {" + busToFlowInstance.mkString(", ") + "}")
          }
        }
      }
      })
    }
  }

  class SimpleToGroupFlowExplanation(flow:Flow,
                                     simple:AtomicProcess,
                                     processorOfSimpleProcess:CPIntVar,
                                     group:ProcessGroup,
                                     procToAnyInstanceOfGroupOnThisProcessor:Map[Processor,CPBoolVar],
                                     busToProcessorToAnyFlow:Map[Int,Map[Processor,CPBoolVar]],
                                     flippedBusses:Boolean) extends FlowMapExplanation(flow) {

    def simpleXGroup: String = if(flippedBusses) " from " else " to "

    override def explanation: Iterable[String] = {
      procToAnyInstanceOfGroupOnThisProcessor.toList.flatMap({ case (proc, anyGroupThere) => {
        if (anyGroupThere.value == 0) None
        else {
          val header = flow.shortString + simpleXGroup + proc.name

          if (processorOfSimpleProcess.value == proc.id) Some(header + " -> local loop")
          else {
            val busToFlowInstance: List[String] = busToProcessorToAnyFlow.toList.flatMap({ case (busID, procToFlowInstance) => procToFlowInstance.get(proc) match {
              case Some(v) if v.value > 0 => Some(hardwareModel.busses(busID).name)
              case _ => None
            }
            })
            require(busToFlowInstance.size == 1)
            Some(header + " -> " + busToFlowInstance.head + "")
          }
        }
      }
      })
    }
  }



  //there is a flow from the atomic to every instance of the subProcess
  def postFromAtomicToSubProcessFlip(fromAtomic: AtomicProcess, toSubProcess: AtomicProcess,flow:Flow,flippedBusses:Boolean): Unit ={
    //le nombre flux indicent à un processeur où il y a des subProcessB doit être égal à ce nombre
    val instancesOfSubProcessPerProcessor:Map[Processor,CPIntVar] = subProcessesIDToSubProcessAndProcessorToNBInstancesOFSubProcessOnProcessor(toSubProcess.id)._2

    val processorToIsAtomicProcessThere:Map[Processor,CPBoolVar] = simpleProcessesIdToProcessorIDVarAndProcessorToIsThereVar(fromAtomic.id)._2

    val busIdToProcessorToFlowInstancesGettingToProcessorThroughBus:Map[Int,Map[Processor,CPIntVar]] =
      SortedMap.empty[Int,Map[Processor,CPIntVar]] ++
        hardwareModel.busses.toList.map(bus => (bus.id,{
          val processorToNumberOfFlowsGettingToProcessorThroughBus:Map[Processor,CPIntVar] =
            SortedMap.empty[Processor,CPIntVar] ++
              bus.sendingToProcessorsFlipped(flippedBusses).map(processor => (processor,
                {val a = CPIntVar(0 to toSubProcess.group.head.n)
                  //these are registered as decision variables
                  accumulateDecisionVariableForFlow(a)
                  a}
                ))

          processorToNumberOfFlowsGettingToProcessorThroughBus
        }))

    accumulateFlowMappingExplanation(
      new SimpleToSubProcessFlowExplanation(
        flow,
        simpleProcessesIdToProcessorIDVarAndProcessorToIsThereVar(fromAtomic.id)._1,
        toSubProcess,
        busIdToProcessorToFlowInstancesGettingToProcessorThroughBus,
        instancesOfSubProcessPerProcessor,flippedBusses))

    //for each processor where there can be some subProcesses,
    // the num of the flows related to this processor on all busses incident to it must be equal to the number of subProcesses running on the processor
    for(processor <- instancesOfSubProcessPerProcessor.keys){
      val flowInstancesGettingToThisProcessor = busIdToProcessorToFlowInstancesGettingToProcessorThroughBus.flatMap(procToNbInstances => procToNbInstances._2.get(processor))

      processorToIsAtomicProcessThere.get(processor)match{
        case None =>
          //checked
          add(sum(flowInstancesGettingToThisProcessor) === instancesOfSubProcessPerProcessor(processor))
        case Some(atomicProcessIsAlsoThere) =>
          for(flow <- flowInstancesGettingToThisProcessor){
            //checked
            add(atomicProcessIsAlsoThere implies (flow === 0))
          }
          //checked
          add(atomicProcessIsAlsoThere
            or (sum(flowInstancesGettingToThisProcessor) === instancesOfSubProcessPerProcessor(processor)))
      }
    }

    //the flow on a bus is the sum of the flows related to all processors
    val busToFlowInstances:Map[Int,CPIntVar] =
      busIdToProcessorToFlowInstancesGettingToProcessorThroughBus
        .mapValues(procToFlowInstancesOnThisBus => sum(procToFlowInstancesOnThisBus.values))

    //there can be no flow if there is no incident subProcess
    //derived, implicit

    //the sum of the flows incident to atomicProcess must be equal to the number of subProcesses
    //minus the number of subProcesses running on the same processor as the atomic one
    for((processor,isAtomicProcessThere) <- processorToIsAtomicProcessThere){
      //if atomicProcess is on this processor, the sum of the flows incident to this processor must be equal to the number of subProcesses
      val bussesWhereAtomicCanTransmit:Iterable[Bus] = hardwareModel.busses.filter(bus => bus.canReceiveFlowFromFlipped(processor,flippedBusses))
      val occupancyOnBussesWhereProcessorCanTransmit:Iterable[CPIntVar] = (if(bussesWhereAtomicCanTransmit.isEmpty) List(CPIntVar(0)) else bussesWhereAtomicCanTransmit.map(bus => busToFlowInstances(bus.id)))
      add(isAtomicProcessThere implies (sum(occupancyOnBussesWhereProcessorCanTransmit) + instancesOfSubProcessPerProcessor.getOrElse(processor,CPIntVar(0)) === toSubProcess.group.head.n))
    }

    //there can be no flow if there is no incident atomicProcess
    //implicit derived

    //next, capacity constraints
    for((busID,flowInstances) <- busToFlowInstances){
      accumulateTransmissionOnBus(busID,flowInstances,flow.bandwidth)
    }
  }

  //simple and group, we assume no multi-cast for now
  def postFromAtomicToProcessGroupFlip(fromSimple: AtomicProcess, toGroup: ProcessGroup, flow:Flow, flipBusses:Boolean){
    //simple and group, we assume no multi-cast for now

    val anyInstanceOfGroupOnThisProcessor:Map[Processor,CPBoolVar] = groupProcessToProcessorToIsRunning(toGroup.id)._2

    val processorToIsAtomicProcessThere:Map[Processor,CPBoolVar] = simpleProcessesIdToProcessorIDVarAndProcessorToIsThereVar(fromSimple.id)._2

    val busToProcessorToAnyFlowFromBusToProcessor:Map[Int,Map[Processor,CPBoolVar]] =
      SortedMap.empty[Int,Map[Processor,CPBoolVar]] ++
        hardwareModel.busses.toList.map(bus => (bus.id,{
          val processorToNumberOfFlows:Map[Processor,CPBoolVar] =
            SortedMap.empty[Processor,CPBoolVar] ++
              bus.sendingToProcessorsFlipped(flipBusses).map(processor => (processor,
                {val a = CPBoolVar("is_flow_to_group_"+toGroup.name+"_to_processor_"+processor.name+"_on_bus_"+bus.name)
                  //these are registered as decision variables
                  accumulateDecisionVariableForFlow(a)
                  a}
                ))
          processorToNumberOfFlows
        }))

    accumulateFlowMappingExplanation(
      new SimpleToGroupFlowExplanation(
        flow,
        fromSimple,
        simpleProcessesIdToProcessorIDVarAndProcessorToIsThereVar(fromSimple.id)._1,
        toGroup,
        anyInstanceOfGroupOnThisProcessor,
        busToProcessorToAnyFlowFromBusToProcessor,flipBusses))

    //for each processor where there can be some subProcesses,
    //the num of the flows related to this processor is one iff there is any subProcess on this processor
    //except is the atomic is also there, in this case there must be no such flow
    for(processor <- anyInstanceOfGroupOnThisProcessor.keys){
      val flowInstancesReachingThisProcessor = busToProcessorToAnyFlowFromBusToProcessor.flatMap(procToAnyInstance => procToAnyInstance._2.get(processor))

      processorToIsAtomicProcessThere.get(processor)match{
        case None =>
          //the atomic process will never be on this same processor
          add(sum(flowInstancesReachingThisProcessor) === anyInstanceOfGroupOnThisProcessor(processor))
        case Some(atomicProcessIsAlsoThere) =>
          //the atomic process might be on the same processor
          for(flow <- flowInstancesReachingThisProcessor){
            //if it is on this processor, there is no such flow
            add(atomicProcessIsAlsoThere implies (flow === 0))
          }
          //otherwise, it is the same condition as above, reified with the atomic is also there.not
          add((atomicProcessIsAlsoThere.not) implies (sum(flowInstancesReachingThisProcessor) === anyInstanceOfGroupOnThisProcessor(processor)))
      }
    }

    //there can be no flow if there is no incident subProcess
    //derived, implicit

    //the sum of the flows incident to atomicProcess must be equal to the number of groups
    //minus one if there is a group on this processor
    for((processor,isAtomicProcessThere) <- processorToIsAtomicProcessThere){
      //if atomicProcess is on this processor, the sum of the flows incident to this processor must be equal to the number of subProcesses
      val bussesWhereAtomicCanTransmit:Iterable[Bus] = hardwareModel.busses.filter(bus => bus.canReceiveFlowFromFlipped(processor,flipBusses))
      val occupancyOnBussesWhereAtomicCanTransmit:Iterable[CPBoolVar] = {
        val tmp = bussesWhereAtomicCanTransmit.map(bus => busToProcessorToAnyFlowFromBusToProcessor(bus.id).getOrElse(processor,CPBoolVar(false)))
        if(tmp.isEmpty) List(CPBoolVar(false)) else tmp
      }
      val anyGroupsOnOtherProcessors:Iterable[CPBoolVar] = {
        val tmp = anyInstanceOfGroupOnThisProcessor.toList.flatMap({case (proc,anyGroupVar) => if(proc != processor)Some(anyGroupVar) else None})
        if(tmp.isEmpty) List(CPBoolVar(false)) else tmp
      }
      add(isAtomicProcessThere implies
        (sum(occupancyOnBussesWhereAtomicCanTransmit) === sum(anyGroupsOnOtherProcessors)))
    }

    //there can be no flow if there is no incident atomicProcess
    //implicit derived

    //next, capacity constraints
    val busToFlowInstances:Map[Int,CPIntVar] =
      busToProcessorToAnyFlowFromBusToProcessor.mapValues(procToAnyFlowInstanceOnThisBus => sum(procToAnyFlowInstanceOnThisBus.values))
    for((busID,flowInstances) <- busToFlowInstances){
      accumulateTransmissionOnBus(busID,flowInstances,flow.bandwidth)
    }
  }

  //transmission takes place on a single data bus
  def postFromAtomicToAtomic(fromAtomic: AtomicProcess, toAtomic: AtomicProcess,flow:Flow): Unit ={
    require(fromAtomic == flow.source)
    require(toAtomic == flow.target)

    val busOfTransmission = CPIntVar(0 to selfLoopBusConstant) ///bus+1 is for the abstract bus in case of self loop

    accumulateFlowMappingExplanation(new SimpleSimpleFlowExplanation(flow,busOfTransmission))
    accumulateDecisionVariableForFlow(busOfTransmission)

    val isBusSelected:Array[CPBoolVar] = Array.tabulate(bussesRange.size)(busId => busOfTransmission.isEq(busId))

    // une trasmission entre deux processeur se produit sur un bus adjacent aux processeur sur lequel tourne les deux process liés par cette transmission.
    // On suppose donc qu'il y a une self-loop de BW infinie sur chaque proceseur
    add(table(simpleProcessesIdToProcessorIdVar(fromAtomic.id), busOfTransmission, processorToBusAdjacencyAbstractBusForSelfLoop1),CPPropagStrength.Strong)
    add(table(busOfTransmission,simpleProcessesIdToProcessorIdVar(toAtomic.id), busToProcessorAdjacencyAbstractBusForSelfLoop1),CPPropagStrength.Strong)

    //on n'utilise pas un bus externe si la source et destination sont sur le même proço
    //le bus de self loop ne peut être utilisé que si les deux processus sont sur le même processeur
    add((simpleProcessesIdToProcessorIdVar(fromAtomic.id) isEq simpleProcessesIdToProcessorIdVar(toAtomic.id)) isEq busOfTransmission.isEq(selfLoopBusConstant))

    if(processorToProcessorAdjacencyWithAddedSelfLoop1.size < hardwareModel.processors.length*hardwareModel.processors.length) {
      //contrainte redondante: deux processus liés par un data flow doivent être placés sur des processeurs adjacents ou sur le même
      //this constraint is only useful if there is no complete connectivity between processors.
      add(table(simpleProcessesIdToProcessorIdVar(fromAtomic.id), simpleProcessesIdToProcessorIdVar(toAtomic.id), processorToProcessorAdjacencyWithAddedSelfLoop1), CPPropagStrength.Strong)
    }
    //ajouter les métriques
    for(potentialBusOfTransmision <- bussesRange){
      accumulateTransmissionOnBus(potentialBusOfTransmision,isBusSelected(potentialBusOfTransmision),flow.bandwidth)
    }
  }

  for(flow <- softwareModel.flows){
    (flow.source, flow.target) match {
      case (fromAtomic: AtomicProcess, toAtomic: AtomicProcess) if fromAtomic.group.isEmpty && toAtomic.group.isEmpty =>
        postFromAtomicToAtomic(fromAtomic, toAtomic, flow)

      case (fromAtomic: AtomicProcess, toSubProcess: AtomicProcess) if fromAtomic.group.isEmpty && !toSubProcess.group.isEmpty =>
        postFromAtomicToSubProcessFlip(fromAtomic, toSubProcess, flow, false)

      case (fromSubProcess: AtomicProcess, toAtomic: AtomicProcess) if toAtomic.group.isEmpty && !fromSubProcess.group.isEmpty =>
        //same as above, but we flip the bus for simplicity
        postFromAtomicToSubProcessFlip(toAtomic, fromSubProcess, flow, true)

      case (fromSimple: AtomicProcess, toGroup: ProcessGroup) if fromSimple.group.isEmpty =>
        postFromAtomicToProcessGroupFlip(fromSimple, toGroup, flow, false)

      case (fromGroup: ProcessGroup,toSimple: AtomicProcess) if toSimple.group.isEmpty =>
        //same as above, but we flip the bus for simplicity
        postFromAtomicToProcessGroupFlip(toSimple, fromGroup, flow, true)

      case _ => throw new Error("unsupported flow:" + flow)
    }
  }

  //declaring the usage of each hw bus
  val dataOnBusses = Array.tabulate(bussesRange.size)(b => CPIntVar(0 to hardwareModel.busses(b).bandwidth))
  //Contrainte: la somme des bw des transmission partageant le même bus sont <= bw totale duus
  for(busId <- bussesRange){
    if(bussesAccumulator(busId).nonEmpty) {
      add(weightedSum(bussesAccumulator(busId).map(_._2).toArray, bussesAccumulator(busId).map(_._1).toArray, dataOnBusses(busId)))
    }else{
      add(dataOnBusses(busId) === 0)
    }
  }

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //fonction objectif: la somme des power à minimizer


  def buildContentOfUnitTaskProcessor(processor: Processor,dimension:String):CPIntVar = {
    val processesThatCanRunOnProcessor = softwareModel.simpleProcesses.toList.filter(_.canRunOn(processor))
    val doesProcessRunOnProcessor = processesThatCanRunOnProcessor.map(process => simpleProcessesIdToProcessorIdVar(process.id).isEq(processor.id))
    val weightOfProcessesOnThisDimension = processesThatCanRunOnProcessor.map(process => process.implementations(processor.processorClass)(dimension))
    val usageOnThisDimension:CPIntVar = CPIntVar(0 to Int.MaxValue/10)
    add(binaryKnapsack(doesProcessRunOnProcessor.toArray, weightOfProcessesOnThisDimension.toArray, usageOnThisDimension))
    usageOnThisDimension
  }

  val dimensionsAndFormulas = hardwareModel.processors.map(processor => {
    val formula = processor.powerModel
    val dimensionsToVar = SortedMap.empty[String,CPIntVar] ++ formula.terms.toList.map(
      (dim:String) => (dim,
        if(processor.processorClass.multiTask) processorsToDimensionsToUsage(processor)(dim)
        else buildContentOfUnitTaskProcessor(processor,dim)))

    (dimensionsToVar,formula)
  })


  def postAndSumFormulas(l:Iterable[(Map[String,CPIntVar],Formula)]):(CPIntVar,Int) = {
    val terms = l.flatMap({case (map,formula) => postFormulas(formula,map)})
    val vars = terms.flatMap(_ match {case PostedAsVar(v) => Some(v) case _ =>  None})
    val summedConsts = terms.foldLeft(0)({case (acc,term) => term match {case PostedAsConst(c) => acc+c case _ =>  acc}})
    (if(vars.size == 1) vars.head else sum(vars.toArray),summedConsts)
  }

  def postFormulas(l:Formula,dimToValue:Map[String,CPIntVar]):Iterable[PostedFormula] = {
    l.splitSum.map(postFormula(_,dimToValue))
  }

  sealed abstract class PostedFormula
  case class PostedAsVar(c:CPIntVar) extends PostedFormula
  case class PostedAsConst(c:Int) extends PostedFormula

  def postFormula(f:Formula,
                  dimToValue:Map[String,CPIntVar]): PostedFormula ={
    f match{
      case Plus(fa,fb) =>
        (postFormula(fa,dimToValue),postFormula(fb,dimToValue)) match{
          case (PostedAsVar(a),PostedAsVar(b)) => PostedAsVar(plus(a,b))
          case (PostedAsVar(a),PostedAsConst(b)) => PostedAsVar(plus(a,b))
          case (PostedAsConst(a),PostedAsVar(b)) => PostedAsVar(plus(b,a))
          case (PostedAsConst(a),PostedAsConst(b)) => PostedAsConst(a+b)
        }
      case Minus(fa,fb) =>
        (postFormula(fa,dimToValue),postFormula(fb,dimToValue)) match{
          case (PostedAsVar(a),PostedAsVar(b)) => PostedAsVar(minus(a,b))
          case (PostedAsVar(a),PostedAsConst(b)) => PostedAsVar(minus(a,b))
          case (PostedAsConst(a),PostedAsVar(b)) => PostedAsVar(minus(b,a))
          case (PostedAsConst(a),PostedAsConst(b)) => PostedAsConst(a-b)
        }
      case Times(fa,fb) =>
        (postFormula(fa,dimToValue),postFormula(fb,dimToValue)) match{
          case (PostedAsVar(a),PostedAsVar(b)) => PostedAsVar(mul(a,b))
          case (PostedAsVar(a),PostedAsConst(b)) => PostedAsVar(mul(a,b))
          case (PostedAsConst(a),PostedAsVar(b)) => PostedAsVar(mul(b,a))
          case (PostedAsConst(a),PostedAsConst(b)) => PostedAsConst(a*b)
        }
      case Const(c) => PostedAsConst(c)
      case Usage(dim) => PostedAsVar(dimToValue(dim))
      case Max(fa,fb) =>
        (postFormula(fa,dimToValue),postFormula(fb,dimToValue)) match{
          case (PostedAsVar(a),PostedAsVar(b)) => PostedAsVar(maximum(List(a,b)))
          case (PostedAsVar(a),PostedAsConst(b)) => PostedAsVar(maximum(List(a,CPIntVar(b))))
          case (PostedAsConst(a),PostedAsVar(b)) => PostedAsVar(maximum(List(CPIntVar(a),b)))
          case (PostedAsConst(a),PostedAsConst(b)) => PostedAsConst(if(a >= b) a else b)
        }
    }
  }

  val (energyConsumption,offset):(CPIntVar,Int) = postAndSumFormulas(dimensionsAndFormulas)

  var sol:Option[Mapping] = None

  minimize(energyConsumption)

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //search procedure

  def findMapping:Option[Mapping] = {
    search{

      binaryFirstFail(decisionVarsForProcesses) ++ binaryFirstFail(decisionVarForBusses)
    }  onSolution{
      //TODO: améliorer la vitesse de sauvegarde, vu que ça va être exécuté à chaque solution, ou utiliser lastSol
      sol = Some(Mapping(
        simpleProcessRange.map(processID => (softwareModel.simpleProcesses(processID),hardwareModel.processors(simpleProcessesIdToProcessorIdVar(processID).value))).toList,
        subProcessesIDToSubProcessAndProcessorToNBInstancesOFSubProcessOnProcessor.toList.map({case (subProcess,procToNbInstance)
        => (subProcess.group.head,procToNbInstance.toList.flatMap({case (proc,nbInstVar) => if(nbInstVar.value == 0) None else Some(proc,nbInstVar.value)}))}),
        flowMapExplanations.flatMap(_.explanation), //flowsRange.map(flowID => (softwareModel.flows(flowID),hardwareModel.bussesIncludingSelfLoops(flowsVars(flowID).value))).toList,
        energyConsumption.value+offset))
    }

    //solver.lastSol
    val stat = start()
    //solve

    println(stat)
    //get info back through indices
    sol
  }
}

//notion de déphasage des communication lors d'un batch?
//notion e mémoire partage? (plus tard, on peut cependant la modélisr comme un processus supplémentaire)
//notion de parallélisation de tâches, en utilisant plusieurs cores; il faut alors spécifier les limites de la parallélisation?

