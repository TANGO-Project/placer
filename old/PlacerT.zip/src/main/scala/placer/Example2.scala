package main.scala.placer

import main.scala.placer.algo.Mapper
import main.scala.placer.metadata.{Const, Usage}
import main.scala.placer.metadata.hw._
import main.scala.placer.metadata.sw.{AtomicProcess, Flow, ProcessGroup, SoftwareModel}

import scala.collection.immutable.{SortedMap, SortedSet}


object Example2 extends App {

  //hardware metamodel
  val cpu = ComputingHardware("cpu",SortedSet("flops"),multiTask = true)
  val fpga = ComputingHardware("fpga",SortedSet("kgate","multiplier"),multiTask = true)
  val gpgpu = ComputingHardware("gpgpu",SortedSet("core"),multiTask = false)

  //hardware model
  val processorA = Processor(cpu,SortedMap("flops" -> 100), "processorA",powerModel = Usage("flops")*Const(10))
  val processorB = Processor(gpgpu,SortedMap("core" -> 110), "co-proc",powerModel = Usage("core"))
  val processorC = Processor(cpu,SortedMap("flops" -> 60), "processorC",powerModel = Usage("flops")*Const(5))
  val processorD = Processor(fpga,SortedMap("kgate" -> 10000, "multiplier" -> 500), "processorD",powerModel = Const(10))

  val globalBus = SymmetricSharedSupportBus(List(processorA, processorB, processorC,processorD), 20, "globalBus")
  val busAB = SymmetricSharedSupportBus(List(processorA, processorB), 100, "busAtoCoProc")
  val busBC = SymmetricSharedSupportBus(List(processorB, processorC), 100, "busCToCoProc")
  val more = SingleWayBus(List(processorC),List(processorD),10,"more")

  val hardwareModel = HardwareModel(
    Array(processorA, processorB, processorC,processorD),
    Array(globalBus,busAB,more,busBC),
    Array(cpu,gpgpu,fpga))

  println(hardwareModel)

  // software model
  val inputting = AtomicProcess(SortedMap(cpu -> SortedMap("flops"->30),fpga -> SortedMap("kgate" -> 1000, "multiplier" -> 300)), "inputting")
  val decoding = AtomicProcess(SortedMap(cpu -> SortedMap("flops"->30),fpga -> SortedMap("kgate" -> 1000, "multiplier" -> 200),gpgpu -> SortedMap("core"->100)), "decoding")
  val atomicTransform = AtomicProcess(SortedMap(cpu -> SortedMap("flops"->4), gpgpu -> SortedMap("core"->1)), "atomicTransforming")
  val transforming = ProcessGroup(atomicTransform,12,"transforming")
  val watermarking = AtomicProcess(SortedMap(cpu -> SortedMap("flops"->30),gpgpu -> SortedMap("core"->100)), "watermarking")
  val encoding = AtomicProcess(SortedMap(cpu -> SortedMap("flops"->31)), "encoding")

  val inputToDecode = Flow(inputting, decoding, 10, "inputToDecode")
  val decodeToTransform = Flow(decoding, atomicTransform, 1, "decodeToTransform")
  val transformToWatermark = Flow(atomicTransform, watermarking, 1, "transformToWatermark")
  val watermarkToEncode = Flow(watermarking, encoding, 49, "watermarkToEncode")

  val sideComm = Flow(inputting, encoding, 9, "side communication")

  val softwareModel = SoftwareModel(
    Array(inputting, decoding, watermarking, encoding),
    Array(transforming),
    Array(inputToDecode, decodeToTransform , transformToWatermark, watermarkToEncode,  sideComm))

  println(softwareModel)

  val mappingSol = Mapper.findMapping(softwareModel,hardwareModel)

  println(mappingSol)
}
