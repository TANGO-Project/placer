package main.scala.pacer.metadata.hw

import main.scala.pacer.metadata._
import scala.collection.immutable.{SortedMap, SortedSet}

case class ComputingHardware(name:String, dimensions:SortedSet[String], multiTask:Boolean = true) extends Indiced with Ordered[ComputingHardware]{
  override def compare(that: ComputingHardware): Int = this.name compare that.name

  override def toString: String = name + (if(multiTask) "(multiTask)" else "(singleTask)") + "{" + dimensions.mkString(",") + "}"
}

case class Processor(processorClass:ComputingHardware,dimensions:SortedMap[String,Int],name:String, powerModel:Formula = null) extends Indiced() with Ordered[Processor]{
  require(dimensions.keySet subsetOf processorClass.dimensions, "unknown dimension specified in " + name + ": " + (dimensions.keySet -- processorClass.dimensions).mkString(","))
  require(processorClass.dimensions subsetOf dimensions.keySet , "missing dimension in " + name + ": " + (processorClass.dimensions-- dimensions.keySet).mkString(","))
  require(powerModel.terms subsetOf processorClass.dimensions, "unknown terms specified in powermodel of " + name + ": " + (powerModel.terms -- processorClass.dimensions).mkString(","))

  override def toString: String = "Processor(" + name + " " + processorClass.name + "(" + dimensions.toList.map({case (a,b) => a + ":" + b}) .mkString(" ") + ") " + "powerModel:" + powerModel.prettyPrint() + ")"

  override def compare(that: Processor): Int = {
    require(this.id != -1)
    require(that.id != -1)
    this.id compare that.id
  }
}

sealed abstract class Bus(val name:String, val bandwidth:Int) extends Indiced(){
  require(bandwidth >= 0, "creating bus " + name + " with unauthorized bandwidth:" + bandwidth)

  def supports(from:Processor,to:Processor):Boolean
  def close()
  def canReceiveFlowFrom(p:Processor):Boolean
  def canSentFlowTo(p:Processor):Boolean
  def receivingFromProcessors:Set[Processor]
  def sendingToProcessors:Set[Processor]

  def canReceiveFlowFromFlipped(p:Processor,flipped:Boolean):Boolean =
    if(flipped) canSentFlowTo(p) else canReceiveFlowFrom(p)

  def sendingToProcessorsFlipped(flipped:Boolean):Set[Processor] =
    if(flipped) receivingFromProcessors else sendingToProcessors
}

case class SymmetricSharedSupportBus(relatedProcessors:List[Processor], override val bandwidth:Int, override val name:String) extends Bus(name,bandwidth) {
  override def toString: String = "SymmetricSharedSupportBus(" + name + " processors:{" + relatedProcessors.map(_.name).mkString(",") + "} maxThroughput:" + bandwidth + ")"
  var relatedProcessorSet:SortedSet[Processor] = null

  def close(): Unit ={
    relatedProcessorSet = SortedSet.empty[Processor] ++ relatedProcessors
  }

  override def supports(from: Processor, to: Processor): Boolean = {
    relatedProcessorSet.contains(from) && relatedProcessorSet.contains(to)
  }

  override def canReceiveFlowFrom(p: Processor): Boolean = relatedProcessorSet.contains(p)

  override def canSentFlowTo(p: Processor): Boolean = relatedProcessorSet.contains(p)

  override def receivingFromProcessors: Set[Processor] = relatedProcessorSet

  override def sendingToProcessors: Set[Processor] = relatedProcessorSet
}

case class SingleWayBus(private val from:List[Processor], to:List[Processor], override val bandwidth:Int, override val name:String) extends Bus(name,bandwidth){
  override def toString: String = "SingleWayBus(" + name + " from:{" + from.map(_.name).mkString(",") + "} to:{" + to.map(_.name).mkString(",") + "}  maxThroughput:" + bandwidth + ")"

  var fromProcessorSet:SortedSet[Processor] = null
  var toProcessorSet:SortedSet[Processor] = null

  def close(): Unit ={
    fromProcessorSet = SortedSet.empty[Processor] ++ from
    toProcessorSet = SortedSet.empty[Processor] ++ to
  }

  override def supports(from: Processor, to: Processor): Boolean = {
    fromProcessorSet.contains(from) && toProcessorSet.contains(to)
  }

  override def canReceiveFlowFrom(p: Processor): Boolean = fromProcessorSet.contains(p)

  override def canSentFlowTo(p: Processor): Boolean = toProcessorSet.contains(p)

  override def receivingFromProcessors: Set[Processor] = fromProcessorSet

  override def sendingToProcessors: Set[Processor] = toProcessorSet
}

case class HardwareModel(processors:Array[Processor],
                         busses:Array[Bus],
                         processorClasses:Array[ComputingHardware]) extends IndiceMaker(){
  setIndices(processors)
  setIndices(busses)
  setIndices(processorClasses)
  busses.foreach(_.close())

  override def toString: String = "HardwareModel(\n" +
    "\tclasses:{\n\t\t" + processorClasses.mkString(",\n\t\t") + "}\n" +
    "\tprocessors:{\n\t\t" + processors.mkString(",\n\t\t") + "} \n" +
    "\tbusses:{\n\t\t" + busses.mkString(",\n\t\t") + "}\n" +
    ")"
}

