package main.scala.pacer.metadata

import scala.collection.immutable.SortedSet

object Formula{
  implicit def intToConst(a:Int):Formula = Const(a)
}

sealed abstract class Formula(subFormula:Formula*){
  def +(b:Formula):Formula = Plus(this,b)
  def -(b:Formula):Formula = Minus(this,b)
  def *(b:Formula):Formula = Times(this,b)

  def terms:SortedSet[String] = subFormula.foldLeft(SortedSet.empty[String])({case (acc,f) => acc ++ f.terms})
  def splitSum:List[Formula] = List(this)
  def prettyPrint(priorityOut:Int = 0):String = toString
  def parenteses(p:Int,outP:Int,s:String):String = if(outP > p) "(" + s + ")" else s

}
case class Plus(a:Formula, b:Formula) extends Formula(a,b) {
  override def splitSum: List[Formula] = List(a,b).flatMap(_.splitSum)
  override def prettyPrint(priorityOut: Int): String = parenteses(1,priorityOut,a.prettyPrint(1) + "+" + b.prettyPrint(1))
}
case class Minus(a:Formula, b:Formula) extends Formula(a,b){
  override def splitSum: List[Formula] = a.splitSum ::: (b.splitSum.map(x => Times(x,Const(-1))))
  override def prettyPrint(priorityOut: Int): String = parenteses(2,priorityOut,a.prettyPrint(1) + "-" + b.prettyPrint(2))
}
case class Times(a:Formula, b:Formula) extends Formula(a,b){
  override def prettyPrint(priorityOut: Int): String = parenteses(3,priorityOut,a.prettyPrint(3) + "*" + b.prettyPrint(3))
}
case class Const(value:Int) extends Formula(){
  override def prettyPrint(priorityOut: Int): String = "" + value
}
case class Usage(dimension:String) extends Formula(){
  override def terms: SortedSet[String] = SortedSet(dimension)
  override def prettyPrint(priorityOut: Int): String = dimension
}
case class Max(a:Formula,b:Formula) extends Formula(a,b)