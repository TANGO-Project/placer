package main.scala.pacer.metadata.sw

import scala.collection.immutable.SortedMap
import main.scala.pacer.metadata._
import main.scala.pacer.metadata.hw._

sealed abstract class Process(val name:String) extends Indiced()

case class AtomicProcess(implementations:SortedMap[ComputingHardware,SortedMap[String,Int]],override val name:String) extends Process(name){

  var group:Option[ProcessGroup] = None

  for((hardware,requiredDimensions) <- implementations) {
    require(requiredDimensions.keySet subsetOf hardware.dimensions, "unknown dimension specified in implementation " + hardware.name + " of " + name + ": " + (requiredDimensions.keySet -- hardware.dimensions).mkString(","))
    require(hardware.dimensions subsetOf requiredDimensions.keySet, "missing dimension in implementation " + hardware.name + " of " + name + ": " + (hardware.dimensions -- requiredDimensions.keySet).mkString(","))
  }

  //override def toString: String = "Process(name:" + name + " implems:{" + implementations.mapValues(_.toList.map({case (a,b) => a + ":" + b}).mkString(",")).mkString(",") + "})"


  override def toString: String = "Process(" + name +
    " implems:{" + implementations.toList.map({case (processor,map) => processor.name + "(" +(map.toList.map({case (a,b) => a + ":" + b}).mkString(","))+")"}).mkString(",") + "})"


  def canRunOn(p:Processor):Boolean = {
    implementations.get(p.processorClass) match {
      case None => return false
      case Some(hwReq) =>
        for ((dim, req) <- hwReq) {
          if (p.dimensions.get(dim).head < req) {
            return false
          }
        }
    }
    true
  }

  def maxInstancesOn(p:Processor):Int = {
    implementations.get(p.processorClass) match {
      case None => 0
      case Some(hwReq) => hwReq.map({case (dim, req) => req / p.dimensions.get(dim).head}).min
    }
  }
}

case class ProcessGroup(processTemplate:AtomicProcess, n:Int, override val name:String) extends Process(name){
  processTemplate.group = Some(this)

  def canPartlyRunOn(p:Processor):Boolean = {
    processTemplate.canRunOn(p)
  }

  override def toString: String = "ProcessGroup(" + name + " n:" + n + " sub:" + processTemplate + ")"
}

//on peut avoir des flux vers les process atomiques, auquel cas, c'est additioné par process sur le même HW; on peutaussi avoir des communication vers le Groupe,
// auquel cas, chaque process a besoi nde la totalité du flux; c'st donc partagé si deux proces du groupe sont sur le même HW

case class Flow(source:Process, target:Process, bandwidth:Int, name:String) extends Indiced(){
  override def toString: String = "Flow("+ name + " " + source.name + "->" + target.name + " throughput:" + bandwidth + ")"

  def shortString:String = "Flow(" + name + " " + source.name + "->" + target.name + ")"
}

case class SoftwareModel(simpleProcesses:Array[AtomicProcess], groups:Array[ProcessGroup], flows:Array[Flow]) extends IndiceMaker(){
  setIndices(simpleProcesses)
  setIndices(groups)
  setIndices(flows)
  require(simpleProcesses.forall(_.group.isEmpty))

  val subProcesses = groups.map(_.processTemplate)
  setIndices(subProcesses)

  require(flows.forall(f => f.source.id != -1 && f.target.id != -1))

  override def toString: String = "SoftwareModel(\n" +
    "\tsimpleProcesses:[\n\t\t" + simpleProcesses.mkString(",\n\t\t") + "] \n" +
    "\tgroups:[\n\t\t" + groups.mkString(",\n\t\t") + "]\n" +
    "\tflows:[\n\t\t" + flows.mkString(",\n\t\t") + "])"
}




