package main.scala.pacer

import main.scala.pacer.algo.HeteDimNoShareEnergyK
import main.scala.pacer.metadata.Usage
import main.scala.pacer.metadata.hw._
import main.scala.pacer.metadata.sw.{AtomicProcess, Flow, ProcessGroup, SoftwareModel}

import scala.collection.immutable.{SortedMap, SortedSet}

/**
 * Created by rdl on 28-09-16.
 */
object Example1 extends App {

  //hardware
  val cpu = ComputingHardware("cpu",SortedSet("flops"),multiTask = true)
  val fpga = ComputingHardware("fpga",SortedSet("kgate","multiplier"),multiTask = true)
  val gpgpu = ComputingHardware("gpgpu",SortedSet("core"),multiTask = false)

  //val mem = ComputingHardware("mem",SortedSet("kb"))

  val processorA = Processor(cpu,SortedMap("flops" -> 100), "procA",powerModel = Usage("flops")*30)
  val processorB = Processor(gpgpu,SortedMap("core" -> 110), "GPGPU",powerModel = Usage("core")*5)
  val processorC = Processor(cpu,SortedMap("flops" -> 60), "procC",powerModel = Usage("flops")*20)
  val processorD = Processor(fpga,SortedMap("kgate" -> 10000, "multiplier" -> 500), "FPGA",powerModel = Usage("kgate") + Usage("multiplier")*200)

  val globalBus = SymmetricSharedSupportBus(List(processorA, processorB, processorC,processorD), 50, "globalBus")
  val busAB = SymmetricSharedSupportBus(List(processorA, processorB), 100, "busAtoGPGPU")
  val busBC = SymmetricSharedSupportBus(List(processorB, processorC), 100, "busCToCoGPGPU")
  val busAD = SingleWayBus(List(processorA),List(processorD), 100, "busAToFPGA")

  val hardwareModel = HardwareModel(
    Array(processorA, processorB, processorC,processorD),
    Array(globalBus, busAB, busBC,busAD),
    Array(cpu,gpgpu,fpga))

  println(hardwareModel)

  // software
  val inputting = AtomicProcess(SortedMap(cpu -> SortedMap("flops"->30),fpga -> SortedMap("kgate" -> 1000, "multiplier" -> 300)), "inputting")
  val decoding = AtomicProcess(SortedMap(cpu -> SortedMap("flops"->50),fpga -> SortedMap("kgate" -> 1000, "multiplier" -> 200),gpgpu -> SortedMap("core"->100)), "decoding")
  val atomicTransform = AtomicProcess(SortedMap(cpu -> SortedMap("flops"->4), gpgpu -> SortedMap("core"->1)), "atomicTransforming")
  val transforming = ProcessGroup(atomicTransform,12,"transforming")
  val watermarking = AtomicProcess(SortedMap(cpu -> SortedMap("flops"->30),fpga->SortedMap("kgate" -> 20,"multiplier" -> 30),gpgpu -> SortedMap("core"->100)), "watermarking")
  val encoding = AtomicProcess(SortedMap(cpu -> SortedMap("flops"->31)), "encoding")

  val inputToDecode = Flow(inputting, decoding, 50, "inputToDecode")
  val decodeToTransform = Flow(decoding, atomicTransform, 2, "decodeToTransform")
  val transformToWatermark = Flow(atomicTransform, watermarking, 2, "transformToWatermark")
  val watermarkToEncode = Flow(watermarking, encoding, 20, "watermarkToEncode")

  val sideComm = Flow(inputting, encoding, 5, "side_comm")

  val comToGroup = Flow(decoding,transforming,1,"group_comm")

  val softwareModel = SoftwareModel(
    Array(inputting, decoding, watermarking, encoding),
    Array(transforming),
    Array(inputToDecode, decodeToTransform, transformToWatermark, watermarkToEncode, sideComm,comToGroup))

  println(softwareModel)


  val mappingSol = HeteDimNoShareEnergyK.findMapping(softwareModel,hardwareModel)

  println(mappingSol)

}
